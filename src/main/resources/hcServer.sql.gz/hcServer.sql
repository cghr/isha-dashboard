-- MySQL dump 10.13  Distrib 5.1.66, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: hcServer
-- ------------------------------------------------------
-- Server version	5.1.66

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `areaId` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `landmark` varchar(45) DEFAULT NULL,
  `pincode` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`areaId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (13,'Wani Plot 1','power station','413401'),(15,'Balewadi','barshi mohal road','413401'),(16,'Kanadi','barshi pathrud road','413502'),(25,'Mangalwar Peth','Temple of Ekvirai Devi','413401'),(109,'Sawargaon','Barshi-Osmanabad Road Via Nari','413404'),(112,'Shelgaon-Marked ','Barshi-Tuljapur Road','413401'),(113,'Shendri','Barshi-Kurduwadi Road (Old Railway Station)','413401'),(114,'Shirale','Barshi-Yermala Road Pathari Dam','413404'),(115,'Shiripat-pimpri','Barshi-Kurduwadi Road','413401'),(119,'Tandulwadi','Barshi-Osmanabad Via-Chikharde','413406'),(120,'Tawadi','Barshi-Khamgaon Road-(Aryan Sugar Factory)','413401'),(122,'Ukkadgaon ','Barshi-Yermala (Yedeshwari Devi) Via-Pangri','413404'),(125,'Upalai (Tho)','Barshi-Kurduwadi Via Khandvi','413401'),(126,'Upale Dumala','Barshi-Tuljapur Road (Ramnath Mandir)','413401'),(129,'Wanewadi','Barshi-Yermala Via-Kuslamb','413404'),(130,'Wangarwadi','Barshi-Kurduwadi Road Via-Khandvi','413401'),(132,'Yelamb','Barshi-Osmanabad Road Via Nari','413404'),(175,'Mamdapur','Barshi-Gormala-via Arangaon','413404'),(184,'Nariwadi','Barshi-Osmanabad via Chikharde','413404'),(196,'Dhanore','Barshi-Yermala Road ','413404'),(202,'Alipur','Barshi-Kurduwadi Road Near Jain Temple','413401'),(206,'Arangaon','Barshi-Gormala Road Via Jamgaon A','413404'),(210,'Bavi','Barshi-Tuljapur Road Pimpalgaon(D) Damp','413403'),(215,'Bhatambare','Barshi-Tuljapur Road Via Jamgaon Pa','413401'),(217,'TAD SAUNDANE','Barshi-Bhum Road Via Mandegaon','413401'),(221,'Chikharde','Barshi-Osmanabad Road Via Nari','413404'),(223,'Chincholi','Barshi-Latur Road Via Pangri','413404'),(225,'Dadshinge','Barshi-Solapur Road Near Soundare','413401'),(226,'Deogaon','Barshi-Bhum Road Via Mankeshwar','413401'),(229,'Pimpalgaon D (Pangri)','Barshi-Latur Via Pangari','413406'),(232,'Dhotre','Barshi-Gormale Via Arangaon','413401'),(233,'Gadegaon','Barshi-Bhum Road Via Mankeshwar','413401'),(234,'Gatachiwadi','Barshi-Bhum Via Koregaon','413404'),(235,'Gaudgaon','Barshi-Tuljapur Road (Nagoba Temple)','413406'),(237,'Ghari','Barshi-Latur Road Via Pangri','413404'),(238,'Gholvewadi','Barshi-Latur Road Via Pangri','413404'),(239,'Gormale','Barshi-Gormale Via Arangaon','413404'),(241,'Halduge','Barshi-Tuljapur Via Upale D Hingani Dam','413401'),(242,'Dhembarewadi','Barshi-Latur Road Via Pangri','413404'),(244,'Hingni (Pangaon)','Barshi-Tuljapur Via Malegaon-Hingani Dam.','413401'),(245,'Indapur','Barshi-Osmanabad Via Chikharde','413404'),(248,'Jahanpur','Barshi-Latur Road Via Pangri','413404'),(249,'Jamgaon-A','Barshi-Yermala Road.','413401'),(250,'Jamgaon-Pa','Barshi-Tuljapur Road via Malegaon','413406'),(256,'Kandalgaon','Barshi-Kandalgaon (ITI College Road)','413411'),(257,'Kapashi','Barshi-Osmanabad Via Nari','413404'),(258,'Kari','Barshi-Kari Road Via Pangri','413404'),(260,'Kasarwadi','Barshi-Mohol Via Korphale','413401'),(262,'kavhe','Landmark-Barshi-Mohol Road','413401'),(263,'Khadkalgaon','Barshi-Pimpalgaon (Dhus)','413409'),(265,'Khamgaon','Barshi-Khamgaon Via Tawadi-  (Aryan Sugar Fac','413401'),(266,'Khandvi','Khandavi-Kurduwadi Road','413401'),(268,'Korphale','Landmark-Barshi-Mohol Road','413401'),(269,'Kuslamb','Barshi-Yermala-Latur Road','413401'),(271,'Mahagaon','Barshi-Tuljapur Road Pimpalgaon(D) Dam','413406'),(272,'Malegaon','Barshi-Tuljapur Road Pimpalgaon (D) Dam','413401'),(282,'Nagobachiwadi','Barshi-Kandalgaon-(Bye pass ITI Road)','413411'),(283,'Nandani','Barshi-Vairag Road Hingani Dam.','413406'),(284,'Nari (Bhandewadi)','Barshi-Osmanabad via  Chikharde','413404'),(286,'Pandhari','Barshi-Pangri Road','413504'),(287,'Pangaon','Barshi Vairag Road','413403'),(288,'Pangri','Barshi-Latur Road','413404'),(289,'Pathri','Barshi-Yermala- Pathari Dam ','413404'),(291,'Pimpalgaon','Barshi-Pimpalgaon (Dhus) Road Via Shelgaon D','413401'),(292,'Pimpalgaon Dhale (Pangaon','Barshi-Tuljapur-Pampalgaon Dam','413406'),(294,'Pimpalwadi','Barshi-Yermala-Kalamb	','413404'),(295,'Waghachiwadi','Barshi-Yermala Road Pathari Dam','413404'),(296,'Pimpri (Ratanjan)','Barshi-Bhatambare Via Jamgaon Pa','413406'),(297,'Puri','Barshi-Latur Road Via Pangri','413404'),(303,'Aljapur','Barshi-Tuljapur Road Via Dhekari','413406'),(304,'Sangamner','Barshi-Tuljapur','413406'),(305,'Ambegaon','Barshi-Vairag Road Jawalgaon Damp','413406'),(306,'Sarole','Barshi-Vairag-Kati Road','413406'),(308,'Saundre','Barshi-Vairag Road','413401'),(311,'SHELGAON (VA)','Barshi-Pimpalgaon Dhus Road','413401'),(312,'Bhandgaon','Barshi-Vairag Road Jawalgaon Damp','413406'),(313,'Bhandegaon','Barshi-Vairag Road Jawalgaon Damp','413406'),(314,'Bhansale','Barshi-Kalambwadi Via Umbarge','413407'),(316,'Bhoinje','Barshi-kurduwadi Road Near shendri station','413401'),(317,'Bhoyare','Barshi-Bhum road via Koregaon','413404'),(320,'Chare','Barshi-Chare','413509'),(322,'Chinchkhopan','Barshi-Vairag Road Jawalgaon Damp','413406'),(324,'Chumb','Barshi-Bhum road via Koregaon','413409'),(328,'Walwad','Barshi-Chare-Walwad Via- Kuslamb','413409'),(331,'Undegaon','Barshi-Pangaon-Surdi','413403'),(332,'Agalgaon','Barshi-Bhum road via Koregaon','413409'),(333,'Babhulgaon','Barshi-Chare Road','413409'),(334,'Mandegaon','Barshi-Bhum via Deolali','413409'),(335,'Belgaon','Barshi-Bhum Road Via Mandegaon','413407'),(336,'Umbarge','Barshi-Khadkoni Road Via Agalgaon','413409'),(342,'Hattij','Barshi-Vairag-Osmanabad Road Jawalgaon Dam.','413406'),(352,'Jotibachiwadi','Barshi-Vairag Road , Jawalgaon Dam','413406'),(353,'Kalambwadi (P)','Barshi-Vairag Road Via-Pangaon','413403'),(354,'Kalambwadi','Barshi-Bhum Road Via Koregaon','413403'),(357,'Kasari','Barshi-Tuljapur Road','413406'),(361,'Kategaon','Barshi-Bhum Via Koregaon','413409'),(362,'Borgaon','Barshi-Chare Road Vai Babhulgaon','413407'),(363,'Dhamangaon','Barshi-Bhum road via Koregaon','413407'),(364,'Khadkoni','Barshi-Khadkoni Road Via Umbarge','413409'),(367,'Koregaon','Barshi-Bhum Road Koregaon','413409'),(373,'Malegaon R','Barshi-Vairag-Osmanabad via Ratanjan','413406'),(378,'Mirzanpur','Barshi-Tuljapur-Via Aljapur','413406'),(380,'Mungashi (Ratan)','Barshi-Vairag-Ratanjan','413406'),(385,'Nimbalk','Barshi-Tuljapur Via Gaudgaon','413406'),(396,'Pimpri (Ratanjan)','Barshi-Bhatambare Via Jamgaon Pa','413406'),(399,'Rastapur','Barshi-Pangaon-Surdi','413401'),(401,'Raulgaon','Barshi-Tuljapur Via Gaudgaon','413406'),(402,'Rui','Barshi-Tuljapur Via Gaudgaon','413406'),(403,'Sakat','Barshi-Vairag Via Pangaon','413403'),(404,'Ambabaichiwadi','Barshi-Vairag Road Jawalgaon Damp','413406'),(412,'Bhalgaon','Barshi-Tuljapur Road Via Guadgaon','413406'),(434,'Zaregaon','Barshi-Tuljapur-Via Gaudgaon','413406');
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment`
--

DROP TABLE IF EXISTS `assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment` (
  `areaId` bigint(10) DEFAULT NULL,
  `teamId` bigint(10) DEFAULT NULL,
  `assigntime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment`
--

LOCK TABLES `assignment` WRITE;
/*!40000 ALTER TABLE `assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authtoken`
--

DROP TABLE IF EXISTS `authtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authtoken` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `token` varchar(100) DEFAULT NULL,
  `time` varchar(100) DEFAULT NULL,
  `expires` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authtoken`
--

LOCK TABLES `authtoken` WRITE;
/*!40000 ALTER TABLE `authtoken` DISABLE KEYS */;
INSERT INTO `authtoken` VALUES (2,'2ca8f454-d156-4cde-8977-c1865aa97ca7',NULL,NULL,'demo',NULL),(3,'c6e824bd-b55b-45bc-acc9-19f82a0c3502',NULL,NULL,'demo',NULL),(9,'3d1cdc7f-81e9-4121-ae4c-ea3cbb4b3d73',NULL,NULL,'demo','user'),(10,'46c0efbe-0101-45a7-bc13-229003cde997',NULL,NULL,'demo','user'),(11,'4be8989c-a2f5-4503-8882-8b36def03e8f',NULL,NULL,'demo','user'),(15,'c088ec12-c219-441a-862f-7e8726086679',NULL,NULL,'demo','user'),(22,'b3fc46e7-30f5-4e62-8348-2994a45f7a63',NULL,NULL,'kiran','manager'),(23,'95bd7b9c-319c-4acf-8014-112c530c17f7',NULL,NULL,'kiran','manager'),(24,'1514ec6c-b7a7-42d5-acfc-c0e36b8f5034',NULL,NULL,'kiran','manager'),(25,'ea4d9efb-1867-478c-b7e6-d11eed0ec843',NULL,NULL,'kiran','manager'),(26,'dca6afb5-2f9a-48d4-899a-50ef690b81b1',NULL,NULL,'demo','user'),(27,'537842b3-b85b-41c8-9c2a-c40ef8858705',NULL,NULL,'kiran','manager'),(28,'257b7870-b938-424e-80a1-484867f1725f',NULL,NULL,'demo','user'),(29,'e1a79bb7-9146-4850-94f1-874d4529711a',NULL,NULL,'demo','user'),(30,'6652a1b7-231d-4858-adad-268e88833138',NULL,NULL,'demo','user'),(31,'d184283d-53bd-4f6c-97bb-c66092fae9cb',NULL,NULL,'kiran','manager'),(32,'2d98831a-ebc4-46c4-913b-f707ec31e378',NULL,NULL,'kiran','manager'),(33,'167067a8-f029-4fe7-9ecd-d4d1f5067eb3',NULL,NULL,'kiran','manager'),(34,'c364d754-2513-4381-bd16-b6de66acb5fb',NULL,NULL,'kiran','manager'),(35,'f3e15f30-8ac8-4dc7-8da6-67e8fcd34bb1',NULL,NULL,'kiran','manager'),(36,'7319677b-6a7b-4552-8e02-d409170d7f8e',NULL,NULL,'kiran','manager'),(37,'d68dc6fd-efcf-4598-b5c4-d3a7562ea71d',NULL,NULL,'kiran','manager'),(38,'85f1741e-8563-4c7b-9099-349ff06f4c70',NULL,NULL,'kiran','manager'),(39,'cd822f44-d47d-4365-8ac2-d466d66d1e43',NULL,NULL,'kiran','manager'),(40,'1fca69f9-741b-4758-a8d4-0cb29a9c8c49',NULL,NULL,'kiran','manager'),(41,'858e954c-a191-464a-a2a9-e845786c67dc',NULL,NULL,'kiran','manager'),(42,'eee909dc-b1be-4fe4-b3ea-23b12fb05f03',NULL,NULL,'kiran','manager'),(43,'66bffbf5-12b3-40b4-bee7-f62b1c069d27',NULL,NULL,'kiran','manager'),(44,'4f9f3b7c-233b-4cf3-876f-6be501f6d865',NULL,NULL,'kiran','manager'),(45,'27bee754-58bc-4a47-a324-6f76fd200481',NULL,NULL,'demo','user'),(46,'7cac9b04-e0ab-4f65-844e-595ee15c1319',NULL,NULL,'demo','user');
/*!40000 ALTER TABLE `authtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datachangelog`
--

DROP TABLE IF EXISTS `datachangelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datachangelog` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `log` text,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datachangelog`
--

LOCK TABLES `datachangelog` WRITE;
/*!40000 ALTER TABLE `datachangelog` DISABLE KEYS */;
INSERT INTO `datachangelog` VALUES (1,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813001\",\"areaId\":\"13\",\"houseNs\":\"101\"}}',NULL),(2,'{\"datastore\":\"enumVisit\",\"data\":{\"householdId\":\"381300101\",\"hhAvailability\":\"Respondents Available\"}}',NULL),(3,'{\"datastore\":\"household\",\"data\":{\"householdId\":\"381300101\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"religion\":\"Hinduism\",\"nameStreet\":\"street\",\"landmark\":\"landmark\",\"mobile1\":\"9090909090\",\"mobile2\":\"9090909090\",\"secondPersonName\":\"second\",\"houseNsNo2\":\"101\",\"nameStreet2\":\"street\",\"landmark2\":\"landmark\",\"secondPersonMobile\":\"9090909090\"}}',NULL),(4,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130010101\",\"householdId\":\"381300101\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"name\":\"member\",\"gender\":\"Male\",\"age\":\"50\"}}',NULL),(5,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130010102\",\"householdId\":\"381300101\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"name\":\"member new\",\"gender\":\"Female\",\"age\":\"40\"}}',NULL),(6,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813001\",\"areaId\":\"13\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"houseNs\":\"900\"}}',NULL),(7,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813001\",\"areaId\":\"13\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"houseNs\":\"5999\"}}',NULL),(8,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813001\",\"areaId\":\"13\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"houseNs\":\"6000\"}}',NULL),(9,'{\"datastore\":\"enumVisit\",\"data\":{\"householdId\":\"381300102\",\"hhAvailability\":\"Respondents Available\"}}',NULL),(10,'{\"datastore\":\"household\",\"data\":{\"householdId\":\"381300102\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"religion\":\"Jainism\",\"nameStreet\":\"2\",\"landmark\":\"2\",\"mobile1\":\"2222222222\",\"mobile2\":\"2222222222\",\"secondPersonName\":\"dda\",\"houseNsNo2\":\"2199\",\"nameStreet2\":\"x\",\"landmark2\":\"x\",\"secondPersonMobile\":\"2222222222\"}}',NULL),(11,'{\"datastore\":\"household\",\"data\":{\"householdId\":\"381300102\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"religion\":\"Jainism\",\"nameStreet\":\"2\",\"landmark\":\"2\",\"mobile1\":\"2222222222\",\"secondPersonName\":\"ram\"}}',NULL),(12,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130010201\",\"householdId\":\"381300102\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"name\":\"kailash\",\"gender\":\"Male\",\"age\":\"50\"}}',NULL),(13,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130010202\",\"householdId\":\"381300102\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"name\":\"kalua\",\"gender\":\"Female\",\"age\":\"51\"}}',NULL),(14,'{\"datastore\":\"householdFoodItems\",\"data\":{\"householdId\":\"381300102\",\"onion\":\"1\",\"garlic\":\"1\",\"turmeric\":\"1\",\"oil\":\"12\"}}',NULL),(15,'{\"datastore\":\"hospInf\",\"data\":{\"householdId\":\"381300102\",\"hospStatus\":\"Yes\",\"hospCount\":\"2\"}}',NULL),(16,'{\"datastore\":\"householdHosp\",\"data\":{\"householdId\":\"381300102\",\"name\":\"kailash\",\"reason\":\"sss\",\"nameHospital\":\"s\"}}',NULL),(17,'{\"datastore\":\"householdHosp\",\"data\":{\"householdId\":\"381300102\",\"name\":\"kailash\",\"reason\":\"sss\",\"nameHospital\":\"s\"}}',NULL),(18,'{\"datastore\":\"deathInf\",\"data\":{\"householdId\":\"381300102\",\"deathStatus\":\"Yes\",\"deathCount\":\"2\"}}',NULL),(19,'{\"datastore\":\"householdDeath\",\"data\":{\"householdId\":\"381300102\",\"name\":\"das\",\"age_value\":\"20\",\"age_unit\":\"Years\",\"gender\":\"Male\"}}',NULL),(20,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300102\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Available\",\"signedConsent\":\"Yes\"}}',NULL),(21,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130010201\",\"user\":38,\"photoStatusInd\":\"Yes, taken\",\"relationshipMale\":\"Self\",\"photoId\":\"Passport\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(22,'{\"datastore\":\"memberBp1\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 09:34:26\",\"bp1Systolic\":\"160\",\"bp1Diastolic\":\"70\",\"heartrate1\":\"78\",\"education\":\"Illiterate\",\"mstatus\":\"Never Married\",\"noChildren\":\"2\",\"childName\":\"ram\",\"occupation\":\"Agriculture labour\"}}',NULL),(23,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813002\",\"areaId\":\"13\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"houseNs\":\"23\"}}',NULL),(24,'{\"datastore\":\"enumVisit\",\"data\":{\"householdId\":\"381300201\",\"hhAvailability\":\"Respondents Available\"}}',NULL),(25,'{\"datastore\":\"memberTobaccoAlcohol\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:07:13\",\"smokeTobacco\":\"Daily\",\"ageStartSmokeCurrent\":\"12\",\"freqCigarettesDay\":\"12\",\"freqBidisDay\":\"0\",\"freqOtherTobaccoDay\":\"0\",\"smokelessTobacco\":\"Less than daily\",\"ageSmokelessTobaccoCurrent\":\"2\",\"freqChewTobaccoWeek\":\"2\",\"freqKhainiLimemixWeek\":\"0\",\"freqGhutkaWeek\":\"0\",\"freqOralTobaccoWeek\":\"0\",\"freqPanmasalaBetelquidWeek\":\"0\",\"freqNasalSnuffWeek\":\"0\",\"freqOtherSmokelessTobaccoWeek\":\"0\",\"consumeAlcohol\":\"Yes\",\"ageStartDrinkingCurrent\":\"7\",\"freqCountryliquor\":\"4\",\"freqSprit\":\"5\",\"freqBeer\":\"0\",\"freqWine\":\"0\"}}',NULL),(26,'{\"datastore\":\"memberPersonalMedicalHistory\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:09:58\",\"rateHealthStatus\":\"Excellent\",\"htn\":\"Yes, on medications\",\"ageHtn\":\"5\",\"dm\":\"No\",\"hd\":\"No\",\"stroke\":\"Unknown\",\"tb\":\"Yes, but not on medications\",\"ageTb\":\"5\",\"asthma\":\"Unknown\",\"cancer\":\"Yes, on medications\",\"ageCancer\":\"5\",\"locationCancerMale\":\"Oesophagus\",\"whitepatchMouth\":\"No\",\"redpatchMouth\":\"No\"}}',NULL),(27,'{\"datastore\":\"memberFamilyMedicalHistory\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:10:36\",\"motherName\":\"ramya\",\"motherState\":\"Mizoram (MZ)\",\"motherdistrict \":\"Fatehgarh Sahib\",\"motherCaste\":\"Lingayat\",\"motherTongue\":\"Marathi\",\"htnMother\":\"Yes, taken\",\"dmMother\":\"Not taken\",\"asthmaMother\":\"Yes\",\"hdMother\":\"No\",\"cancerMother\":\"Yes\",\"htnFather\":\"No\",\"dmFather\":\"Yes, on medications\",\"asthmaFather\":\"Yes, on medications\",\"hdFather\":\"Yes, on medications\",\"cancerFather\":\"No\"}}',NULL),(28,'{\"datastore\":\"memberPhysicalActivities\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:12:50\",\"servantHh\":\"No\",\"hhMaintanence\":\"0.5\",\"cooking\":\"1.5\",\"walking\":\"2.5\",\"cycling\":\"8.5\",\"takingcare\":\"1\",\"carryingwater\":\"0.5\",\"othersActivity\":\"Yes\",\"othersSpecify\":\"jumping\",\"othersActivityTime\":\"0.5\",\"hrsSleepNight\":\"6\",\"hrsSleepDaylight\":\"3.5\",\"hrsSleepAfterEat\":\"7.5\",\"hrsWatchtvDay\":\"8\",\"hrsWatchtvHoliday\":\"8.5\",\"sportsExsCurrent\":\"Yes\",\"sportExs1\":\"Gymnastics\",\"ageStartSportExs1\":\"12\",\"timeSportExs1Wk\":\"2\",\"ageStartSportExs2\":\"12\",\"timeSportExs2Wk\":\"9\",\"sportsExsPast\":\"No\",\"nowMale\":\"3\",\"ageTwentyMale\":\"3\",\"ageTenMale\":\"3\"}}',NULL),(29,'{\"datastore\":\"memberBp2\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:15:20\",\"bp2Systolic\":\"170\",\"bp2Diastolic\":\"80\",\"heartrate2\":\"111\"}}',NULL),(30,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813002\",\"areaId\":\"13\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"houseNs\":\"20\"}}',NULL),(31,'{\"datastore\":\"enumVisit\",\"data\":{\"householdId\":\"381300201\",\"hhAvailability\":\"Respondents Available\"}}',NULL),(32,'{\"datastore\":\"ffqGeneral\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:15:29\",\"typeFood\":\"Veg\",\"veg\":\"Yes\",\"fastStatus\":\"Yes\",\"fastHours\":\"12\",\"noDaysFast\":\"2\",\"fastDiet\":\"Fast with Sabut Dana\"}}',NULL),(33,'{\"datastore\":\"ffqBeverages\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:16:12\",\"milkCow_frequency\":\"2\",\"milkCow_unit\":\"Glass\",\"milkCow_measure\":\"1\",\"milkBuffalo_frequency\":\"6\",\"milkBuffalo_measure\":\"1\",\"milkBuffalo_unit\":\"Cup (Big)\",\"tea_frequency\":\"7\",\"tea_measure\":\"1\",\"tea_unit\":\"Cup (Small)\"}}',NULL),(34,'{\"datastore\":\"ffqBeverages\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:17:01\",\"milkCow_frequency\":\"1\",\"milkBuffalo_frequency\":\"1\",\"tea_frequency\":\"1\",\"milkCow_measure\":\"1\",\"milkBuffalo_measure\":\"1\",\"tea_measure\":\"1\",\"milkCow_unit\":\"Glass\",\"milkBuffalo_unit\":\"Glass\",\"tea_unit\":\"Cup (Small)\"}}',NULL),(35,'{\"datastore\":\"ffqCereals\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:17:33\",\"jwari_frequency\":\"1\",\"makka_frequency\":\"1\",\"chapati_frequency\":\"1\",\"rice_frequency\":\"1\",\"jwari_measure\":\"1\",\"makka_measure\":\"1\",\"chapati_measure\":\"1\",\"rice_measure\":\"1\"}}',NULL),(36,'{\"datastore\":\"ffqPulses\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:18:13\",\"aamtiM_frequency\":\"2\",\"aamtiM_measure\":\"1\",\"mokaliM_frequency\":\"2\",\"varanT_frequency\":\"2\",\"aamtiT_frequency\":\"2\",\"mokaliT_frequency\":\"2\",\"matki_frequency\":\"2\",\"patal_frequency\":\"2\",\"pithale_frequency\":\"2\",\"dalmirchi_frequency\":\"2\",\"mokaliM_measure\":\"1\",\"varanT_measure\":\"1\",\"aamtiT_measure\":\"1\",\"mokaliT_measure\":\"1\",\"matki_measure\":\"1\",\"patal_measure\":\"1\",\"pithale_measure\":\"1\",\"dalmirchi_measure\":\"1\",\"aamtiM_unit\":\"Dish\",\"mokaliM_unit\":\"Wati\"}}',NULL),(37,'{\"datastore\":\"ffqVeg\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:18:51\",\"sukhi_frequency\":\"1\",\"sarbarit_frequency\":\"1\",\"dodkePatal_frequency\":\"1\",\"gawarseng_frequency\":\"7\",\"vegMethi_frequency\":\"1\",\"pattakobi_frequency\":\"1\",\"palakbhaji_frequency\":\"1\",\"chukapalak_frequency\":\"1\",\"harbharabhaji_frequency\":\"1\",\"ghewdyachiseng_frequency\":\"1\",\"sevgyachiseng_frequency\":\"7\",\"sukhi_measure\":\"1\",\"sarbarit_measure\":\"1\",\"dodkePatal_measure\":\"1\",\"gawarseng_measure\":\"1\",\"vegMethi_measure\":\"1\",\"pattakobi_measure\":\"1\",\"palakbhaji_measure\":\"1\",\"chukapalak_measure\":\"1\",\"harbharabhaji_measure\":\"1\",\"ghewdyachiseng_measure\":\"1\",\"sevgyachiseng_measure\":\"1\"}}',NULL),(38,'{\"datastore\":\"ffqRaw\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:19:49\",\"rawMethi_frequency\":\"1\",\"gawarisheng_frequency\":\"1\",\"kakadi_frequency\":\"1\",\"kande_frequency\":\"1\",\"lasun_frequency\":\"1\",\"rawMethi_measure\":\"1\",\"gawarisheng_measure\":\"1\",\"kakadi_measure\":\"1\",\"kande_measure\":\"1\",\"lasun_measure\":\"1\"}}',NULL),(39,'{\"datastore\":\"ffqFruits\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:20:16\",\"keli_frequency\":\"1\",\"amba_frequency\":\"1\",\"peru_frequency\":\"1\",\"kalingad_frequency\":\"1\",\"bor_frequency\":\"1\",\"keli_measure\":\"1\",\"amba_measure\":\"1\",\"peru_measure\":\"1\",\"kalingad_measure\":\"1\",\"bor_measure\":\"1\"}}',NULL),(40,'{\"datastore\":\"ffqJuice\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:20:23\",\"ambyacha_frequency\":\"1\",\"nimbusharbat_frequency\":\"1\",\"ambyacha_measure\":\"1\",\"nimbusharbat_measure\":\"1\"}}',NULL),(41,'{\"datastore\":\"ffqNonVeg\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:20:27\",\"eggBurgi_frequency\":\"1\",\"eggCurry_frequency\":\"1\",\"mutton_frequency\":\"1\",\"fish_frequency\":\"1\",\"chicken_frequency\":\"1\",\"eggBurgi_measure\":\"1\",\"eggOmlet_measure\":\"1\",\"eggCurry_measure\":\"1\",\"mutton_measure\":\"1\",\"fish_measure\":\"1\",\"chicken_measure\":\"1\",\"eggOmlet_frequency\":\"1\"}}',NULL),(42,'{\"datastore\":\"ffqSweets\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:20:41\",\"gulwani_frequency\":\"1\",\"Jalebi_frequency\":\"1\",\"ladubundhi_frequency\":\"1\",\"pooranpoli_frequency\":\"1\",\"shira_frequency\":\"1\",\"gulwani_measure\":\"1\",\"Jalebi_measure\":\"1\",\"ladubundhi_measure\":\"1\",\"pooranpoli_measure\":\"1\",\"shira_measure\":\"1\"}}',NULL),(43,'{\"datastore\":\"ffqSpiceMix\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:20:52\",\"chatani_frequency\":\"1\",\"jawa_frequency\":\"1\",\"kairi_frequency\":\"1\",\"lasunSheng_frequency\":\"1\",\"sengdana_frequency\":\"1\",\"tomato_frequency\":\"1\",\"thecha_frequency\":\"1\",\"pickleAmba_frequency\":\"1\",\"pickleLimbu_frequency\":\"1\",\"chatani_measure\":\"1\",\"jawa_measure\":\"1\",\"kairi_measure\":\"1\",\"lasunSheng_measure\":\"1\",\"sengdana_measure\":\"1\",\"tomato_measure\":\"1\",\"thecha_measure\":\"1\",\"pickleAmba_measure\":\"1\",\"pickleLimbu_measure\":\"1\"}}',NULL),(44,'{\"datastore\":\"household\",\"data\":{\"householdId\":\"381300201\",\"houseId\":\"3813002\",\"areaId\":\"13\",\"religion\":\"Hinduism\",\"nameStreet\":\"Mahatma Gandhi Road\",\"landmark\":\"Near Sardar Patel Statue\",\"mobile1\":\"9812345234\",\"mobile2\":\"9347528390\",\"secondPersonName\":\"Chaganbhai\",\"houseNsNo2\":\"28\",\"nameStreet2\":\"Yashoda Street\",\"landmark2\":\"Ram Mandir\",\"secondPersonMobile\":\"8734657890\"}}',NULL),(45,'{\"datastore\":\"ffqSnacks\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:21:08\",\"papad_frequency\":\"1\",\"Pohe_frequency\":\"1\",\"upit_frequency\":\"1\",\"bhajiBesankande_frequency\":\"1\",\"wada_frequency\":\"1\",\"chiwada_frequency\":\"1\",\"shev_frequency\":\"1\",\"papad_measure\":\"1\",\"Pohe_measure\":\"1\",\"upit_measure\":\"1\",\"bhajiBesankande_measure\":\"1\",\"wada_measure\":\"1\",\"chiwada_measure\":\"1\",\"shev_measure\":\"1\",\"kurwadi_frequency\":\"1\",\"kurwadi_measure\":\"1\"}}',NULL),(46,'{\"datastore\":\"ffqSalt\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:21:26\",\"selfReportSalt\":\"Often\",\"extraSaltDining\":\"Yes\",\"modeAddSalt\":\"Spoon\",\"freqAddSalt\":\"Often\",\"amtSaltConsump\":\"Too little\",\"mnthlySaltUse\":\"111\",\"ctrlSaltIntake\":\"Rarely\"}}',NULL),(47,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130020101\",\"householdId\":\"381300201\",\"houseId\":\"3813002\",\"areaId\":\"13\",\"name\":\"Renukaben\",\"gender\":\"Female\",\"age\":\"58\"}}',NULL),(48,'{\"datastore\":\"ffqFoodAdditives\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-26 10:21:56\",\"gheeDalda\":\"Yes\",\"gheePure\":\"Yes\",\"lemon\":\"Yes\"}}',NULL),(49,'{\"datastore\":\"invitationCard\",\"data\":{\"memberId\":\"38130010201\",\"phn\":\"111111\",\"rePhn\":\"111111\"}}',NULL),(50,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300101\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Available\",\"signedConsent\":\"Yes\"}}',NULL),(51,'{\"datastore\":\"memberBp1\",\"data\":{\"memberId\":\"38130010101\",\"starttime\":\"2014-06-26 11:00:27\",\"bp1Systolic\":\"120\",\"bp1Diastolic\":\"60\",\"heartrate1\":\"90\",\"education\":\"Below primary\",\"mstatus\":\"Refused to Answer\",\"noChildren\":\"2\",\"childName\":\"ram\",\"occupation\":\"Farmers\"}}',NULL),(52,'{\"datastore\":\"memberTobaccoAlcohol\",\"data\":{\"memberId\":\"38130010101\",\"starttime\":\"2014-06-26 11:03:34\",\"smokeTobacco\":\"Refused to answer\",\"smokelessTobacco\":\"Daily\",\"ageSmokelessTobaccoCurrent\":\"1\",\"freqChewTobaccoDay\":\"2\",\"freqKhainiLimemixDay\":\"2\",\"freqGhutkaDay\":\"0\",\"freqOralTobaccoDay\":\"0\",\"freqPanmasalaBetelquidDay\":\"0\",\"freqNasalSnuffDay\":\"0\",\"freqOtherSmokelessTobaccoDay\":\"0\",\"consumeAlcohol\":\"Yes\",\"ageStartDrinkingCurrent\":\"0\",\"freqCountryliquor\":\"2\",\"freqSprit\":\"0\",\"freqBeer\":\"0\",\"freqWine\":\"0\"}}',NULL),(53,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300102\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Available\",\"signedConsent\":\"Yes\"}}',NULL),(54,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130010202\",\"user\":38,\"photoStatusInd\":\"No\",\"relationshipFemale\":\"Spouse\",\"photoId\":\"Ration card\",\"photoStatusId\":\"No\"}}',NULL),(55,'{\"datastore\":\"memberBp1\",\"data\":{\"memberId\":\"38130010202\",\"starttime\":\"2014-06-26 11:07:59\",\"bp1Systolic\":\"120\",\"bp1Diastolic\":\"80\",\"heartrate1\":\"110\",\"education\":\"Hr. Sec/ Class XII/ Pre-Univ\",\"mstatus\":\"Married\",\"noChildren\":\"1\",\"childName\":\"ram\",\"occupation\":\"Housewife\"}}',NULL),(56,'{\"datastore\":\"memberTobaccoAlcohol\",\"data\":{\"memberId\":\"38130010202\",\"starttime\":\"2014-06-26 11:08:29\",\"smokeTobacco\":\"Daily\",\"ageStartSmokeCurrent\":\"0\",\"freqCigarettesDay\":\"0\",\"freqBidisDay\":\"0\",\"freqOtherTobaccoDay\":\"00\",\"smokelessTobacco\":\"Refused to answer\",\"consumeAlcohol\":\"Yes\",\"ageStartDrinkingCurrent\":\"0\",\"freqCountryliquor\":\"0\",\"freqSprit\":\"0\",\"freqBeer\":\"0\",\"freqWine\":\"0\",\"drinkStatusHusband\":\"Does not drink much (occasional drinker)\",\"freqDrinkHusband\":\"7\"}}',NULL),(57,'{\"datastore\":\"memberPersonalMedicalHistory\",\"data\":{\"memberId\":\"38130010202\",\"starttime\":\"2014-06-26 11:11:30\",\"rateHealthStatus\":\"Excellent\",\"htn\":\"No\",\"dm\":\"No\",\"hd\":\"No\",\"stroke\":\"No\",\"tb\":\"No\",\"asthma\":\"Yes, but not on medications\",\"ageAsthma\":\"0\",\"cancer\":\"Yes, on medications\",\"ageCancer\":\"1\",\"locationCancerFemale\":\"Breast\",\"whitepatchMouth\":\"No\",\"redpatchMouth\":\"No\"}}',NULL),(58,'{\"datastore\":\"memberFamilyMedicalHistory\",\"data\":{\"memberId\":\"38130010202\",\"starttime\":\"2014-06-26 11:14:14\",\"motherName\":\"kavita\",\"motherState\":\"Goa (GA)\",\"motherdistrict \":\"Karimnagar\",\"motherCaste\":\"Dhangar\",\"motherTongue\":\"Bhili/Bhilodi\",\"htnMother\":\"No\",\"dmMother\":\"No\",\"asthmaMother\":\"No\",\"hdMother\":\"No\",\"cancerMother\":\"No\",\"htnFather\":\"No\",\"dmFather\":\"No\",\"asthmaFather\":\"No\",\"hdFather\":\"No\",\"cancerFather\":\"No\"}}',NULL),(59,'{\"datastore\":\"memberPhysicalActivities\",\"data\":{\"memberId\":\"38130010202\",\"starttime\":\"2014-06-26 11:26:54\",\"servantHh\":\"No\",\"hhMaintanence\":\"7.5\",\"cooking\":\"7.5\",\"walking\":\"7.5\",\"cycling\":\"8\",\"takingcare\":\"8.5\",\"carryingwater\":\"8\",\"othersActivity\":\"Yes\",\"othersSpecify\":\"ff\",\"othersActivityTime\":\"8\",\"hrsSleepNight\":\"9\",\"hrsSleepDaylight\":\"8.5\",\"hrsSleepAfterEat\":\"8\",\"hrsWatchtvDay\":\"7.5\",\"hrsWatchtvHoliday\":\"8\",\"sportsExsCurrent\":\"Yes\",\"sportExs1\":\"Gajge\",\"ageStartSportExs1\":\"1\",\"timeSportExs1Wk\":\"12\",\"ageStartSportExs2\":\"2\",\"timeSportExs2Wk\":\"23\",\"sportsExsPast\":\"No\",\"nowFemale\":\"2\",\"ageTwentyFemale\":\"2\",\"ageTenFemale\":\"3\"}}',NULL),(60,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813001\",\"areaId\":\"13\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"houseNs\":\"23\"}}',NULL),(61,'{\"datastore\":\"household\",\"data\":{\"householdId\":\"381300101\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"religion\":\"Hinduism\",\"nameStreet\":\"2dfsdf\",\"landmark\":\"wefwer\",\"mobile1\":\"1111111111\",\"mobile2\":\"1111111111\",\"secondPersonName\":\"sdfsd\",\"houseNsNo2\":\"23\",\"nameStreet2\":\"23\",\"landmark2\":\"23\",\"secondPersonMobile\":\"1111111111\"}}',NULL),(62,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130010101\",\"householdId\":\"381300101\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"name\":\"sdfsdf\",\"gender\":\"Male\",\"age\":\"23\"}}',NULL),(63,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130010102\",\"user\":38,\"photoStatusInd\":\"Yes, taken\",\"relationshipFemale\":\"Self\",\"photoId\":\"Aadhaar card\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(64,'{\"datastore\":\"memberBp1\",\"data\":{\"memberId\":\"38130010102\",\"starttime\":\"2014-06-26 23:56:54\",\"bp1Systolic\":\"123\",\"bp1Diastolic\":\"122\",\"heartrate1\":\"67\",\"education\":\"Illiterate\",\"mstatus\":\"Never Married\",\"noChildren\":\"2\",\"childName\":\"sdfsdf\",\"occupation\":\"Salaried\"}}',NULL),(65,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130010102\",\"user\":38,\"photoStatusInd\":\"Yes, taken\",\"relationshipFemale\":\"Self\",\"photoId\":\"Aadhaar card\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(66,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130010102\",\"user\":38,\"photoStatusInd\":\"Yes, taken\",\"relationshipFemale\":\"Self\",\"photoId\":\"Aadhaar card\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(67,'{\"datastore\":\"memberBp1\",\"data\":{\"memberId\":\"38130010102\",\"starttime\":\"2014-06-27 00:07:45\",\"bp1Systolic\":\"120\",\"bp1Diastolic\":\"111\",\"heartrate1\":\"90\",\"education\":\"Illiterate\",\"mstatus\":\"Never Married\",\"noChildren\":\"0\",\"occupation\":\"Salaried\"}}',NULL),(68,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130010102\",\"user\":38,\"photoStatusInd\":\"Unknown\",\"relationshipFemale\":\"Self\",\"photoId\":\"Aadhaar card\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(69,'{\"datastore\":\"memberPersonalMedicalHistory\",\"data\":{\"memberId\":\"38130010102\",\"starttime\":\"2014-06-27 00:25:51\",\"rateHealthStatus\":\"Excellent\",\"htn\":\"No\",\"dm\":\"No\",\"hd\":\"No\",\"stroke\":\"No\",\"tb\":\"No\",\"asthma\":\"No\",\"cancer\":\"No\",\"whitepatchMouth\":\"Yes\",\"redpatchMouth\":\"Yes\",\"ageMenarche\":\"12\",\"pregnantCurrent\":\"Yes\",\"pregnantPast\":\"Yes\",\"noTimesPregnantPast\":\"2\",\"age1stPregnant\":\"14\",\"outcome1stPregnant\":\"Baby was born alive\",\"bf1stBaby\":\"Yes\",\"nomnths1stBf\":\"12\",\"age2ndPregnant\":\"11\",\"outcome2ndPregnant\":\"Baby was born alive\",\"bf2ndBaby\":\"Yes\",\"nomnths2ndBf\":\"23\",\"contraceptives\":\"None\",\"periodsStatus\":\"No\",\"ageStopPeriods\":\"34\"}}',NULL),(70,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130010102\",\"user\":38,\"photoStatusInd\":\"Yes, taken\",\"relationshipFemale\":\"Self\",\"photoId\":\"Aadhaar card\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(71,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300101\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Available\",\"signedConsent\":\"Yes\"}}',NULL),(72,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300101\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Available\",\"signedConsent\":\"Yes\"}}',NULL),(73,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300201\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Available\",\"signedConsent\":\"Yes\"}}',NULL),(74,'{\"datastore\":\"memberImage\",\"data\":{\"consent\":\"38130020101_consent\",\"memberId\":\"38130020101\"}}',NULL),(75,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130020101\",\"user\":38,\"photoStatusInd\":\"Yes, taken\",\"relationshipFemale\":\"Self\",\"photoId\":\"Aadhaar card\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(76,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813001\",\"areaId\":\"13\",\"houseNs\":\"101\"}}',NULL),(77,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300201\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Unavailable\"}}',NULL),(78,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130020101\",\"user\":38,\"photoStatusInd\":\"Yes, taken\",\"relationshipFemale\":\"Self\",\"photoId\":\"Aadhaar card\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(79,'{\"datastore\":\"hcMember\",\"data\":{\"memberId\":\"38130020101\",\"user\":38,\"photoStatusInd\":\"Yes, taken\",\"relationshipFemale\":\"Self\",\"photoId\":\"Aadhaar card\",\"photoStatusId\":\"Yes, taken\"}}',NULL),(80,'{\"datastore\":\"ffqGeneral\",\"data\":{\"memberId\":\"38130010101\",\"starttime\":\"2014-06-27 11:32:29\",\"typeFood\":\"Veg\",\"veg\":\"Yes\",\"fastStatus\":\"Yes\",\"fastHours\":\"1\",\"noDaysFast\":\"1\",\"fastDiet\":\"Eat nothing during fasting\"}}',NULL),(81,'{\"datastore\":\"memberBp1\",\"data\":{\"memberId\":\"38130020101\",\"starttime\":\"2014-06-27 11:27:12\",\"bp1Systolic\":\"120\",\"bp1Diastolic\":\"110\",\"heartrate1\":\"110\",\"education\":\"Below primary\",\"mstatus\":\"Married\",\"noChildren\":\"2\",\"childName\":\"kumar\",\"occupation\":\"Farmers\"}}',NULL),(82,'{\"datastore\":\"memberTobaccoAlcohol\",\"data\":{\"memberId\":\"38130020101\",\"starttime\":\"2014-06-27 11:35:24\",\"smokeTobacco\":\"Daily\",\"ageStartSmokeCurrent\":\"12\",\"freqCigarettesDay\":\"12\",\"freqBidisDay\":\"12\",\"freqOtherTobaccoDay\":\"12\",\"smokelessTobacco\":\"Daily\",\"ageSmokelessTobaccoCurrent\":\"12\",\"freqChewTobaccoDay\":\"12\",\"freqKhainiLimemixDay\":\"12\",\"freqGhutkaDay\":\"12\",\"freqOralTobaccoDay\":\"1\",\"freqPanmasalaBetelquidDay\":\"1\",\"freqNasalSnuffDay\":\"1\",\"freqOtherSmokelessTobaccoDay\":\"1\",\"consumeAlcohol\":\"Yes\",\"ageStartDrinkingCurrent\":\"12\",\"freqCountryliquor\":\"3\",\"freqSprit\":\"1\",\"freqBeer\":\"1\",\"freqWine\":\"1\",\"drinkStatusHusband\":\"Does not drink at all\"}}',NULL),(83,'{\"datastore\":\"ffqGeneral\",\"data\":{\"memberId\":\"38130010101\",\"starttime\":\"2014-06-27 14:23:29\",\"typeFood\":\"Veg\",\"veg\":\"Yes\",\"fastStatus\":\"Yes\",\"fastHours\":\"1\",\"noDaysFast\":\"1\",\"fastDiet\":\"Eat nothing during fasting\"}}',NULL),(84,'{\"datastore\":\"ffqBeverages\",\"data\":{\"memberId\":\"38130010101\",\"starttime\":\"2014-06-27 14:23:41\",\"milkCow_unit\":\"Cup (Big)\",\"milkCow_frequency\":\"2\",\"milkBuffalo_frequency\":\"2\",\"tea_frequency\":\"2\",\"milkCow_measure\":\"1\",\"milkBuffalo_measure\":\"1\",\"tea_measure\":\"1\"}}',NULL),(85,'{\"datastore\":\"ffqBeverages\",\"data\":{\"memberId\":\"38130010101\",\"starttime\":\"2014-06-27 14:23:41\",\"milkCow_unit\":\"Cup (Big)\",\"milkCow_frequency\":\"2\",\"milkBuffalo_frequency\":\"2\",\"tea_frequency\":\"2\",\"milkCow_measure\":\"1\",\"milkBuffalo_measure\":\"1\",\"tea_measure\":\"1\"}}',NULL),(86,'{\"datastore\":\"memberPersonalMedicalHistory\",\"data\":{\"memberId\":\"38130020101\",\"starttime\":\"2014-06-27 14:59:55\",\"rateHealthStatus\":\"Excellent\",\"htn\":\"No\",\"dm\":\"No\",\"hd\":\"No\",\"stroke\":\"No\",\"tb\":\"No\",\"asthma\":\"No\",\"cancer\":\"No\",\"whitepatchMouth\":\"Yes\",\"redpatchMouth\":\"Yes\"}}',NULL),(87,'{\"datastore\":\"memberFamilyMedicalHistory\",\"data\":{\"memberId\":\"38130020101\",\"starttime\":\"2014-06-27 15:15:36\",\"motherName\":\"sdfsd\",\"motherState\":\"Tamil Nadu (TN)\",\"motherdistrict \":\"Salem\",\"motherCaste\":\"Brahman\",\"motherTongue\":\"Tamil\",\"htnMother\":\"Yes, taken\",\"dmMother\":\"Yes, taken\",\"asthmaMother\":\"Yes, taken\",\"hdMother\":\"Yes, taken\",\"cancerMother\":\"Yes, taken\",\"htnFather\":\"No\",\"dmFather\":\"No\",\"asthmaFather\":\"No\",\"hdFather\":\"No\",\"cancerFather\":\"No\"}}',NULL),(88,'{\"datastore\":\"memberPhysicalActivities\",\"data\":{\"memberId\":\"38130020101\",\"starttime\":\"2014-06-27 15:17:11\",\"servantHh\":\"Yes\",\"servantParttime\":\"1\",\"servantFulltime\":\"1\",\"hhMaintanence\":\"3\",\"cooking\":\"2\",\"walking\":\"0\",\"othersActivity\":\"Yes\",\"othersSpecify\":\"sdfsd\",\"othersActivityTime\":\"0\",\"hrsSleepNight\":\"0\",\"hrsSleepDaylight\":\"2\",\"hrsSleepAfterEat\":\"0\",\"hrsWatchtvDay\":\"0\",\"hrsWatchtvHoliday\":\"1.5\",\"sportsExsCurrent\":\"Yes\",\"sportExs1\":\"Aerobics\",\"ageStartSportExs1\":\"12\",\"timeSportExs1Wk\":\"12\",\"sportExs2\":\"Aerobics\",\"ageStartSportExs2\":\"12\",\"timeSportExs2Wk\":\"12\",\"sportsExsPast\":\"Yes\",\"sportExs1Past\":\"Andhala topi\",\"ageStartSportExs1Past\":\"12\",\"ageStopSportExs1\":\"12\",\"timeSportExs1WkPast\":\"12\",\"sportExs2Past\":\"Atayapataya\",\"ageStartSportExs2Past\":\"12\",\"ageStopSportExs2\":\"12\",\"timeSportExs2WkPast\":\"12\",\"nowFemale\":\"4\",\"ageTwentyFemale\":\"1\",\"ageTenFemale\":\"1\"}}',NULL),(89,'{\"datastore\":\"memberBp2\",\"data\":{\"memberId\":\"38130020101\",\"starttime\":\"2014-06-27 15:49:07\",\"bp2Systolic\":\"120\",\"bp2Diastolic\":\"110\",\"heartrate2\":\"123\"}}',NULL),(90,'{\"datastore\":\"ffqGeneral\",\"data\":{\"memberId\":\"38130020101\",\"starttime\":\"2014-06-27 15:49:18\",\"typeFood\":\"Veg\",\"veg\":\"Yes\",\"fastStatus\":\"Yes\",\"fastHours\":\"12\",\"noDaysFast\":\"1\",\"fastDiet\":\"Eat nothing during fasting\"}}',NULL),(91,'{\"datastore\":\"ffqGeneral\",\"data\":{\"memberId\":\"38130020101\",\"starttime\":\"2014-06-27 15:49:18\",\"typeFood\":\"Veg\",\"veg\":\"Yes\",\"fastStatus\":\"Yes\",\"fastHours\":\"12\",\"noDaysFast\":\"1\",\"fastDiet\":\"Eat nothing during fasting\"}}',NULL),(92,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300101\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Available\",\"signedConsent\":\"Yes\"}}',NULL),(93,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813003\",\"areaId\":\"13\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"houseNs\":\"12\"}}',NULL),(94,'{\"datastore\":\"enumVisit\",\"data\":{\"householdId\":\"381300301\",\"hhAvailability\":\"Respondents Available\"}}',NULL),(95,'{\"datastore\":\"household\",\"data\":{\"householdId\":\"381300301\",\"houseId\":\"3813003\",\"areaId\":\"13\",\"religion\":\"Hinduism\",\"nameStreet\":\"sdfsd\",\"landmark\":\"sdfsd\",\"mobile1\":\"1111111111\",\"mobile2\":\"1111111111\",\"secondPersonName\":\"sdfds\",\"houseNsNo2\":\"12\",\"nameStreet2\":\"sdf\",\"landmark2\":\"sdf\",\"secondPersonMobile\":\"1111111111\"}}',NULL),(96,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130030101\",\"householdId\":\"381300301\",\"houseId\":\"3813003\",\"areaId\":\"13\",\"name\":\"sesdf\",\"gender\":\"Male\",\"age\":\"45\"}}',NULL),(97,'{\"datastore\":\"householdFoodItems\",\"data\":{\"householdId\":\"381300301\",\"onion\":\"23\",\"garlic\":\"23\",\"turmeric\":\"23\",\"oil\":\"23\"}}',NULL),(98,'{\"datastore\":\"ffqGeneral\",\"data\":{\"memberId\":\"38130010201\",\"starttime\":\"2014-06-27 16:25:45\",\"typeFood\":\"Veg\",\"veg\":\"Yes\",\"fastStatus\":\"Yes\",\"fastHours\":\"12\",\"noDaysFast\":\"1\",\"fastDiet\":\"Eat nothing during fasting\"}}',NULL),(99,'{\"datastore\":\"house\",\"data\":{\"houseId\":\"3813001\",\"areaId\":\"13\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"houseNs\":\"12\"}}',NULL),(100,'{\"datastore\":\"enumVisit\",\"data\":{\"householdId\":\"381300103\",\"hhAvailability\":\"Respondents Available\"}}',NULL),(101,'{\"datastore\":\"household\",\"data\":{\"householdId\":\"381300103\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"religion\":\"Hinduism\",\"nameStreet\":\"a\",\"landmark\":\"a\",\"mobile1\":\"9999999999\",\"mobile2\":\"\",\"secondPersonName\":\"sss\",\"houseNsNo2\":\"134\",\"nameStreet2\":\"a\",\"landmark2\":\"a\",\"secondPersonMobile\":\"9999999999\"}}',NULL),(102,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130010301\",\"householdId\":\"381300103\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"name\":\"sumi\",\"gender\":\"Male\",\"age\":\"39\"}}',NULL),(103,'{\"datastore\":\"member\",\"data\":{\"memberId\":\"38130010302\",\"householdId\":\"381300103\",\"houseId\":\"3813001\",\"areaId\":\"13\",\"name\":\"sat\",\"gender\":\"Male\",\"age\":\"45\"}}',NULL),(104,'{\"datastore\":\"householdFoodItems\",\"data\":{\"householdId\":\"381300103\",\"onion\":\"1\",\"garlic\":\"100\",\"turmeric\":\"100\",\"oil\":\"1\"}}',NULL),(105,'{\"datastore\":\"householdFoodItems\",\"data\":{\"householdId\":\"381300103\",\"onion\":\"1\",\"garlic\":\"12\",\"turmeric\":\"1\",\"oil\":\"12\"}}',NULL),(106,'{\"datastore\":\"hospInf\",\"data\":{\"householdId\":\"381300103\",\"hospStatus\":\"Yes\",\"hospCount\":\"2\"}}',NULL),(107,'{\"datastore\":\"householdHosp\",\"data\":{\"householdId\":\"381300103\",\"name\":\"sumi\",\"reason\":\"duh\",\"nameHospital\":\"aaa\"}}',NULL),(108,'{\"datastore\":\"householdHosp\",\"data\":{\"householdId\":\"381300103\",\"name\":\"sat\",\"reason\":\"aaa\",\"nameHospital\":\"aaa\"}}',NULL),(109,'{\"datastore\":\"deathInf\",\"data\":{\"householdId\":\"381300103\",\"deathStatus\":\"Yes\",\"deathCount\":\"1\"}}',NULL),(110,'{\"datastore\":\"householdDeath\",\"data\":{\"householdId\":\"381300103\",\"name\":\"aaa\",\"age_value\":\"23\",\"age_unit\":\"Years\",\"gender\":\"Male\"}}',NULL),(111,'{\"datastore\":\"hcVisit\",\"data\":{\"householdId\":\"381300103\",\"gps_latitude\":\"12.7435\",\"gps_longitude\":\"17.9872\",\"hhVisit\":\"Available\",\"signedConsent\":\"Yes\"}}',NULL),(112,'{\"datastore\":\"memberTobaccoAlcohol\",\"data\":{\"memberId\":\"38130010301\",\"starttime\":\"2014-06-27 15:10:37\",\"smokeTobacco\":\"Daily\",\"ageStartSmokeCurrent\":\"12\",\"freqCigarettesDay\":\"2\",\"freqBidisDay\":\"0\",\"freqOtherTobaccoDay\":\"0\",\"smokelessTobacco\":\"Not at all\",\"smokelessTobaccoPast\":\"No\",\"consumeAlcohol\":\"Yes\",\"ageStartDrinkingCurrent\":\"12\",\"freqCountryliquor\":\"1\",\"freqSprit\":\"0\",\"freqBeer\":\"0\",\"freqWine\":\"0\",\"drinkStatusHusband\":\"Does not drink much (occasional drinker)\",\"freqDrinkHusband\":\"6\"}}',NULL);
/*!40000 ALTER TABLE `datachangelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deathInf`
--

DROP TABLE IF EXISTS `deathInf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deathInf` (
  `householdId` bigint(10) NOT NULL,
  `deathStatus` varchar(100) DEFAULT NULL,
  `deathCount` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`householdId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deathInf`
--

LOCK TABLES `deathInf` WRITE;
/*!40000 ALTER TABLE `deathInf` DISABLE KEYS */;
INSERT INTO `deathInf` VALUES (381300102,'Yes','2'),(381300103,'Yes','1');
/*!40000 ALTER TABLE `deathInf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enumVisit`
--

DROP TABLE IF EXISTS `enumVisit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enumVisit` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `householdId` bigint(10) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hhAvailability` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enumVisit`
--

LOCK TABLES `enumVisit` WRITE;
/*!40000 ALTER TABLE `enumVisit` DISABLE KEYS */;
INSERT INTO `enumVisit` VALUES (1,381300101,NULL,'2014-06-26 06:49:44','Respondents Available'),(2,381300102,NULL,'2014-06-26 13:16:41','Respondents Available'),(3,381300201,NULL,'2014-06-26 14:02:06','Respondents Available'),(4,381300201,NULL,'2014-06-26 14:15:25','Respondents Available'),(5,381300301,NULL,'2014-06-27 10:28:38','Respondents Available'),(6,381300103,NULL,'2014-06-27 18:50:17','Respondents Available');
/*!40000 ALTER TABLE `enumVisit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqBeverages`
--

DROP TABLE IF EXISTS `ffqBeverages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqBeverages` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `milkCow_frequency` varchar(100) DEFAULT NULL,
  `milkCow_measure` varchar(100) DEFAULT NULL,
  `milkCow_unit` varchar(100) DEFAULT NULL,
  `milkBuffalo_frequency` varchar(100) DEFAULT NULL,
  `milkBuffalo_measure` varchar(100) DEFAULT NULL,
  `milkBuffalo_unit` varchar(100) DEFAULT NULL,
  `tea_frequency` varchar(100) DEFAULT NULL,
  `tea_measure` varchar(100) DEFAULT NULL,
  `tea_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqBeverages`
--

LOCK TABLES `ffqBeverages` WRITE;
/*!40000 ALTER TABLE `ffqBeverages` DISABLE KEYS */;
INSERT INTO `ffqBeverages` VALUES (38130010201,'2014-06-26 10:17:01','2014-06-26 14:16:17','1','1','Glass','1','1','Glass','1','1','Cup (Small)'),(38130010101,'2014-06-27 14:23:41','2014-06-27 08:57:49','2','1','Cup (Big)','2','1',NULL,'2','1',NULL);
/*!40000 ALTER TABLE `ffqBeverages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqCereals`
--

DROP TABLE IF EXISTS `ffqCereals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqCereals` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `jwari_frequency` varchar(100) DEFAULT NULL,
  `jwari_measure` varchar(100) DEFAULT NULL,
  `jwari_unit` varchar(100) DEFAULT NULL,
  `makka_frequency` varchar(100) DEFAULT NULL,
  `makka_measure` varchar(100) DEFAULT NULL,
  `makka_unit` varchar(100) DEFAULT NULL,
  `chapati_frequency` varchar(100) DEFAULT NULL,
  `chapati_measure` varchar(100) DEFAULT NULL,
  `chapati_unit` varchar(100) DEFAULT NULL,
  `rice_frequency` varchar(100) DEFAULT NULL,
  `rice_measure` varchar(100) DEFAULT NULL,
  `rice_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqCereals`
--

LOCK TABLES `ffqCereals` WRITE;
/*!40000 ALTER TABLE `ffqCereals` DISABLE KEYS */;
INSERT INTO `ffqCereals` VALUES (38130010201,'2014-06-26 10:17:33','2014-06-26 14:17:35','1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL);
/*!40000 ALTER TABLE `ffqCereals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqFoodAdditives`
--

DROP TABLE IF EXISTS `ffqFoodAdditives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqFoodAdditives` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gheeDalda` varchar(100) DEFAULT NULL,
  `gheePure` varchar(100) DEFAULT NULL,
  `lemon` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqFoodAdditives`
--

LOCK TABLES `ffqFoodAdditives` WRITE;
/*!40000 ALTER TABLE `ffqFoodAdditives` DISABLE KEYS */;
INSERT INTO `ffqFoodAdditives` VALUES (38130010201,'2014-06-26 10:21:56','2014-06-26 14:21:24','Yes','Yes','Yes');
/*!40000 ALTER TABLE `ffqFoodAdditives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqFruits`
--

DROP TABLE IF EXISTS `ffqFruits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqFruits` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `keli_frequency` varchar(100) DEFAULT NULL,
  `keli_measure` varchar(100) DEFAULT NULL,
  `keli_unit` varchar(100) DEFAULT NULL,
  `amba_frequency` varchar(100) DEFAULT NULL,
  `amba_measure` varchar(100) DEFAULT NULL,
  `amba_unit` varchar(100) DEFAULT NULL,
  `peru_frequency` varchar(100) DEFAULT NULL,
  `peru_measure` varchar(100) DEFAULT NULL,
  `peru_unit` varchar(100) DEFAULT NULL,
  `kalingad_frequency` varchar(100) DEFAULT NULL,
  `kalingad_measure` varchar(100) DEFAULT NULL,
  `kalingad_unit` varchar(100) DEFAULT NULL,
  `bor_frequency` varchar(100) DEFAULT NULL,
  `bor_measure` varchar(100) DEFAULT NULL,
  `bor_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqFruits`
--

LOCK TABLES `ffqFruits` WRITE;
/*!40000 ALTER TABLE `ffqFruits` DISABLE KEYS */;
INSERT INTO `ffqFruits` VALUES (38130010201,'2014-06-26 10:20:16','2014-06-26 14:19:45','1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL);
/*!40000 ALTER TABLE `ffqFruits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqGeneral`
--

DROP TABLE IF EXISTS `ffqGeneral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqGeneral` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `typeFood` varchar(100) DEFAULT NULL,
  `veg` varchar(100) DEFAULT NULL,
  `nonveg` varchar(100) DEFAULT NULL,
  `fastStatus` varchar(100) DEFAULT NULL,
  `fastHours` varchar(100) DEFAULT NULL,
  `noDaysFast` varchar(100) DEFAULT NULL,
  `fastDiet` varchar(100) DEFAULT NULL,
  `otherfastDiet` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqGeneral`
--

LOCK TABLES `ffqGeneral` WRITE;
/*!40000 ALTER TABLE `ffqGeneral` DISABLE KEYS */;
INSERT INTO `ffqGeneral` VALUES (38130010201,'2014-06-27 16:25:45','2014-06-26 14:15:33','Veg','Yes',NULL,'Yes','12','1','Eat nothing during fasting',NULL),(38130010101,'2014-06-27 14:23:29','2014-06-27 06:03:00','Veg','Yes',NULL,'Yes','1','1','Eat nothing during fasting',NULL),(38130020101,'2014-06-27 15:49:18','2014-06-27 10:25:59','Veg','Yes',NULL,'Yes','12','1','Eat nothing during fasting',NULL);
/*!40000 ALTER TABLE `ffqGeneral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqJuice`
--

DROP TABLE IF EXISTS `ffqJuice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqJuice` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ambyacha_frequency` varchar(100) DEFAULT NULL,
  `ambyacha_measure` varchar(100) DEFAULT NULL,
  `ambyacha_unit` varchar(100) DEFAULT NULL,
  `nimbusharbat_frequency` varchar(100) DEFAULT NULL,
  `nimbusharbat_measure` varchar(100) DEFAULT NULL,
  `nimbusharbat_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqJuice`
--

LOCK TABLES `ffqJuice` WRITE;
/*!40000 ALTER TABLE `ffqJuice` DISABLE KEYS */;
INSERT INTO `ffqJuice` VALUES (38130010201,'2014-06-26 10:20:23','2014-06-26 14:19:49','1','1',NULL,'1','1',NULL);
/*!40000 ALTER TABLE `ffqJuice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqNonVeg`
--

DROP TABLE IF EXISTS `ffqNonVeg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqNonVeg` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `eggBurgi_frequency` varchar(100) DEFAULT NULL,
  `eggBurgi_measure` varchar(100) DEFAULT NULL,
  `eggBurgi_unit` varchar(100) DEFAULT NULL,
  `eggOmlet_frequency` varchar(100) DEFAULT NULL,
  `eggOmlet_measure` varchar(100) DEFAULT NULL,
  `eggOmlet_unit` varchar(100) DEFAULT NULL,
  `eggCurry_frequency` varchar(100) DEFAULT NULL,
  `eggCurry_measure` varchar(100) DEFAULT NULL,
  `eggCurry_unit` varchar(100) DEFAULT NULL,
  `mutton_frequency` varchar(100) DEFAULT NULL,
  `mutton_measure` varchar(100) DEFAULT NULL,
  `mutton_unit` varchar(100) DEFAULT NULL,
  `fish_frequency` varchar(100) DEFAULT NULL,
  `fish_measure` varchar(100) DEFAULT NULL,
  `fish_unit` varchar(100) DEFAULT NULL,
  `chicken_frequency` varchar(100) DEFAULT NULL,
  `chicken_measure` varchar(100) DEFAULT NULL,
  `chicken_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqNonVeg`
--

LOCK TABLES `ffqNonVeg` WRITE;
/*!40000 ALTER TABLE `ffqNonVeg` DISABLE KEYS */;
INSERT INTO `ffqNonVeg` VALUES (38130010201,'2014-06-26 10:20:27','2014-06-26 14:20:03','1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL);
/*!40000 ALTER TABLE `ffqNonVeg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqPulses`
--

DROP TABLE IF EXISTS `ffqPulses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqPulses` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `aamtiM_frequency` varchar(100) DEFAULT NULL,
  `aamtiM_measure` varchar(100) DEFAULT NULL,
  `aamtiM_unit` varchar(100) DEFAULT NULL,
  `mokaliM_frequency` varchar(100) DEFAULT NULL,
  `mokaliM_measure` varchar(100) DEFAULT NULL,
  `mokaliM_unit` varchar(100) DEFAULT NULL,
  `varanT_frequency` varchar(100) DEFAULT NULL,
  `varanT_measure` varchar(100) DEFAULT NULL,
  `varanT_unit` varchar(100) DEFAULT NULL,
  `aamtiT_frequency` varchar(100) DEFAULT NULL,
  `aamtiT_measure` varchar(100) DEFAULT NULL,
  `aamtiT_unit` varchar(100) DEFAULT NULL,
  `mokaliT_frequency` varchar(100) DEFAULT NULL,
  `mokaliT_measure` varchar(100) DEFAULT NULL,
  `mokaliT_unit` varchar(100) DEFAULT NULL,
  `matki_frequency` varchar(100) DEFAULT NULL,
  `matki_measure` varchar(100) DEFAULT NULL,
  `matki_unit` varchar(100) DEFAULT NULL,
  `patal_frequency` varchar(100) DEFAULT NULL,
  `patal_measure` varchar(100) DEFAULT NULL,
  `patal_unit` varchar(100) DEFAULT NULL,
  `pithale_frequency` varchar(100) DEFAULT NULL,
  `pithale_measure` varchar(100) DEFAULT NULL,
  `pithale_unit` varchar(100) DEFAULT NULL,
  `dalmirchi_frequency` varchar(100) DEFAULT NULL,
  `dalmirchi_measure` varchar(100) DEFAULT NULL,
  `dalmirchi_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqPulses`
--

LOCK TABLES `ffqPulses` WRITE;
/*!40000 ALTER TABLE `ffqPulses` DISABLE KEYS */;
INSERT INTO `ffqPulses` VALUES (38130010201,'2014-06-26 10:18:13','2014-06-26 14:18:13','2','1','Dish','2','1','Wati','2','1',NULL,'2','1',NULL,'2','1',NULL,'2','1',NULL,'2','1',NULL,'2','1',NULL,'2','1',NULL);
/*!40000 ALTER TABLE `ffqPulses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqRaw`
--

DROP TABLE IF EXISTS `ffqRaw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqRaw` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rawMethi_frequency` varchar(100) DEFAULT NULL,
  `rawMethi_measure` varchar(100) DEFAULT NULL,
  `rawMethi_unit` varchar(100) DEFAULT NULL,
  `gawarisheng_frequency` varchar(100) DEFAULT NULL,
  `gawarisheng_measure` varchar(100) DEFAULT NULL,
  `gawarisheng_unit` varchar(100) DEFAULT NULL,
  `kakadi_frequency` varchar(100) DEFAULT NULL,
  `kakadi_measure` varchar(100) DEFAULT NULL,
  `kakadi_unit` varchar(100) DEFAULT NULL,
  `kande_frequency` varchar(100) DEFAULT NULL,
  `kande_measure` varchar(100) DEFAULT NULL,
  `kande_unit` varchar(100) DEFAULT NULL,
  `lasun_frequency` varchar(100) DEFAULT NULL,
  `lasun_measure` varchar(100) DEFAULT NULL,
  `lasun_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqRaw`
--

LOCK TABLES `ffqRaw` WRITE;
/*!40000 ALTER TABLE `ffqRaw` DISABLE KEYS */;
INSERT INTO `ffqRaw` VALUES (38130010201,'2014-06-26 10:19:49','2014-06-26 14:19:38','1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL);
/*!40000 ALTER TABLE `ffqRaw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqSalt`
--

DROP TABLE IF EXISTS `ffqSalt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqSalt` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `selfReportSalt` varchar(100) DEFAULT NULL,
  `extraSaltDining` varchar(100) DEFAULT NULL,
  `modeAddSalt` varchar(100) DEFAULT NULL,
  `freqAddSalt` varchar(100) DEFAULT NULL,
  `amtSaltConsump` varchar(100) DEFAULT NULL,
  `mnthlySaltUse` varchar(100) DEFAULT NULL,
  `ctrlSaltIntake` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqSalt`
--

LOCK TABLES `ffqSalt` WRITE;
/*!40000 ALTER TABLE `ffqSalt` DISABLE KEYS */;
INSERT INTO `ffqSalt` VALUES (38130010201,'2014-06-26 10:21:26','2014-06-26 14:21:15','Often','Yes','Spoon','Often','Too little','111','Rarely');
/*!40000 ALTER TABLE `ffqSalt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqSnacks`
--

DROP TABLE IF EXISTS `ffqSnacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqSnacks` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `papad_frequency` varchar(100) DEFAULT NULL,
  `papad_measure` varchar(100) DEFAULT NULL,
  `papad_unit` varchar(100) DEFAULT NULL,
  `Pohe_frequency` varchar(100) DEFAULT NULL,
  `Pohe_measure` varchar(100) DEFAULT NULL,
  `Pohe_unit` varchar(100) DEFAULT NULL,
  `upit_frequency` varchar(100) DEFAULT NULL,
  `upit_measure` varchar(100) DEFAULT NULL,
  `upit_unit` varchar(100) DEFAULT NULL,
  `bhajiBesankande_frequency` varchar(100) DEFAULT NULL,
  `bhajiBesankande_measure` varchar(100) DEFAULT NULL,
  `bhajiBesankande_unit` varchar(100) DEFAULT NULL,
  `wada_frequency` varchar(100) DEFAULT NULL,
  `wada_measure` varchar(100) DEFAULT NULL,
  `wada_unit` varchar(100) DEFAULT NULL,
  `chiwada_frequency` varchar(100) DEFAULT NULL,
  `chiwada_measure` varchar(100) DEFAULT NULL,
  `chiwada_unit` varchar(100) DEFAULT NULL,
  `shev_frequency` varchar(100) DEFAULT NULL,
  `shev_measure` varchar(100) DEFAULT NULL,
  `shev_unit` varchar(100) DEFAULT NULL,
  `kurwadi_frequency` varchar(100) DEFAULT NULL,
  `kurwadi_measure` varchar(100) DEFAULT NULL,
  `kurwadi_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqSnacks`
--

LOCK TABLES `ffqSnacks` WRITE;
/*!40000 ALTER TABLE `ffqSnacks` DISABLE KEYS */;
INSERT INTO `ffqSnacks` VALUES (38130010201,'2014-06-26 10:21:08','2014-06-26 14:20:47','1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL);
/*!40000 ALTER TABLE `ffqSnacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqSpiceMix`
--

DROP TABLE IF EXISTS `ffqSpiceMix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqSpiceMix` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `chatani_frequency` varchar(100) DEFAULT NULL,
  `chatani_measure` varchar(100) DEFAULT NULL,
  `chatani_unit` varchar(100) DEFAULT NULL,
  `jawa_frequency` varchar(100) DEFAULT NULL,
  `jawa_measure` varchar(100) DEFAULT NULL,
  `jawa_unit` varchar(100) DEFAULT NULL,
  `kairi_frequency` varchar(100) DEFAULT NULL,
  `kairi_measure` varchar(100) DEFAULT NULL,
  `kairi_unit` varchar(100) DEFAULT NULL,
  `lasunSheng_frequency` varchar(100) DEFAULT NULL,
  `lasunSheng_measure` varchar(100) DEFAULT NULL,
  `lasunSheng_unit` varchar(100) DEFAULT NULL,
  `sengdana_frequency` varchar(100) DEFAULT NULL,
  `sengdana_measure` varchar(100) DEFAULT NULL,
  `sengdana_unit` varchar(100) DEFAULT NULL,
  `tomato_frequency` varchar(100) DEFAULT NULL,
  `tomato_measure` varchar(100) DEFAULT NULL,
  `tomato_unit` varchar(100) DEFAULT NULL,
  `thecha_frequency` varchar(100) DEFAULT NULL,
  `thecha_measure` varchar(100) DEFAULT NULL,
  `thecha_unit` varchar(100) DEFAULT NULL,
  `pickleAmba_frequency` varchar(100) DEFAULT NULL,
  `pickleAmba_measure` varchar(100) DEFAULT NULL,
  `pickleAmba_unit` varchar(100) DEFAULT NULL,
  `pickleLimbu_frequency` varchar(100) DEFAULT NULL,
  `pickleLimbu_measure` varchar(100) DEFAULT NULL,
  `pickleLimbu_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqSpiceMix`
--

LOCK TABLES `ffqSpiceMix` WRITE;
/*!40000 ALTER TABLE `ffqSpiceMix` DISABLE KEYS */;
INSERT INTO `ffqSpiceMix` VALUES (38130010201,'2014-06-26 10:20:52','2014-06-26 14:20:30','1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL);
/*!40000 ALTER TABLE `ffqSpiceMix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqSweets`
--

DROP TABLE IF EXISTS `ffqSweets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqSweets` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gulwani_frequency` varchar(100) DEFAULT NULL,
  `gulwani_measure` varchar(100) DEFAULT NULL,
  `gulwani_unit` varchar(100) DEFAULT NULL,
  `Jalebi_frequency` varchar(100) DEFAULT NULL,
  `Jalebi_measure` varchar(100) DEFAULT NULL,
  `Jalebi_unit` varchar(100) DEFAULT NULL,
  `ladubundhi_frequency` varchar(100) DEFAULT NULL,
  `ladubundhi_measure` varchar(100) DEFAULT NULL,
  `ladubundhi_unit` varchar(100) DEFAULT NULL,
  `pooranpoli_frequency` varchar(100) DEFAULT NULL,
  `pooranpoli_measure` varchar(100) DEFAULT NULL,
  `pooranpoli_unit` varchar(100) DEFAULT NULL,
  `shira_frequency` varchar(100) DEFAULT NULL,
  `shira_measure` varchar(100) DEFAULT NULL,
  `shira_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqSweets`
--

LOCK TABLES `ffqSweets` WRITE;
/*!40000 ALTER TABLE `ffqSweets` DISABLE KEYS */;
INSERT INTO `ffqSweets` VALUES (38130010201,'2014-06-26 10:20:41','2014-06-26 14:20:13','1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL);
/*!40000 ALTER TABLE `ffqSweets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ffqVeg`
--

DROP TABLE IF EXISTS `ffqVeg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ffqVeg` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sukhi_frequency` varchar(100) DEFAULT NULL,
  `sukhi_measure` varchar(100) DEFAULT NULL,
  `sukhi_unit` varchar(100) DEFAULT NULL,
  `sarbarit_frequency` varchar(100) DEFAULT NULL,
  `sarbarit_measure` varchar(100) DEFAULT NULL,
  `sarbarit_unit` varchar(100) DEFAULT NULL,
  `dodkePatal_frequency` varchar(100) DEFAULT NULL,
  `dodkePatal_measure` varchar(100) DEFAULT NULL,
  `dodkePatal_unit` varchar(100) DEFAULT NULL,
  `gawarseng_frequency` varchar(100) DEFAULT NULL,
  `gawarseng_measure` varchar(100) DEFAULT NULL,
  `gawarseng_unit` varchar(100) DEFAULT NULL,
  `vegMethi_frequency` varchar(100) DEFAULT NULL,
  `vegMethi_measure` varchar(100) DEFAULT NULL,
  `vegMethi_unit` varchar(100) DEFAULT NULL,
  `pattakobi_frequency` varchar(100) DEFAULT NULL,
  `pattakobi_measure` varchar(100) DEFAULT NULL,
  `pattakobi_unit` varchar(100) DEFAULT NULL,
  `palakbhaji_frequency` varchar(100) DEFAULT NULL,
  `palakbhaji_measure` varchar(100) DEFAULT NULL,
  `palakbhaji_unit` varchar(100) DEFAULT NULL,
  `chukapalak_frequency` varchar(100) DEFAULT NULL,
  `chukapalak_measure` varchar(100) DEFAULT NULL,
  `chukapalak_unit` varchar(100) DEFAULT NULL,
  `harbharabhaji_frequency` varchar(100) DEFAULT NULL,
  `harbharabhaji_measure` varchar(100) DEFAULT NULL,
  `harbharabhaji_unit` varchar(100) DEFAULT NULL,
  `ghewdyachiseng_frequency` varchar(100) DEFAULT NULL,
  `ghewdyachiseng_measure` varchar(100) DEFAULT NULL,
  `ghewdyachiseng_unit` varchar(100) DEFAULT NULL,
  `sevgyachiseng_frequency` varchar(100) DEFAULT NULL,
  `sevgyachiseng_measure` varchar(100) DEFAULT NULL,
  `sevgyachiseng_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ffqVeg`
--

LOCK TABLES `ffqVeg` WRITE;
/*!40000 ALTER TABLE `ffqVeg` DISABLE KEYS */;
INSERT INTO `ffqVeg` VALUES (38130010201,'2014-06-26 10:18:51','2014-06-26 14:19:10','1','1',NULL,'1','1',NULL,'1','1',NULL,'7','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'1','1',NULL,'7','1',NULL);
/*!40000 ALTER TABLE `ffqVeg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filechangelog`
--

DROP TABLE IF EXISTS `filechangelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filechangelog` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `filename` varchar(100) DEFAULT NULL,
  `filestore` varchar(100) DEFAULT NULL,
  `fileId` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filechangelog`
--

LOCK TABLES `filechangelog` WRITE;
/*!40000 ALTER TABLE `filechangelog` DISABLE KEYS */;
INSERT INTO `filechangelog` VALUES (1,'38130020101_consent','memberImage','memberConsent',NULL);
/*!40000 ALTER TABLE `filechangelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcMember`
--

DROP TABLE IF EXISTS `hcMember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcMember` (
  `memberId` bigint(10) NOT NULL,
  `householdId` bigint(10) DEFAULT NULL,
  `user` bigint(10) DEFAULT NULL,
  `photoStatusInd` varchar(100) DEFAULT NULL,
  `reasonNoPhotoInd` varchar(100) DEFAULT NULL,
  `otherResonNoPhoto` varchar(100) DEFAULT NULL,
  `relationshipMale` varchar(100) DEFAULT NULL,
  `relationshipFemale` varchar(100) DEFAULT NULL,
  `photoId` varchar(100) DEFAULT NULL,
  `otherPhotoId` varchar(100) DEFAULT NULL,
  `photoStatusId` varchar(100) DEFAULT NULL,
  `reasonNoPhotoId` varchar(100) DEFAULT NULL,
  `othersNoPhoto` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcMember`
--

LOCK TABLES `hcMember` WRITE;
/*!40000 ALTER TABLE `hcMember` DISABLE KEYS */;
INSERT INTO `hcMember` VALUES (38130010201,NULL,38,'Yes, taken',NULL,NULL,'Self',NULL,'Passport',NULL,'Yes, taken',NULL,NULL),(38130010202,NULL,38,'No',NULL,NULL,NULL,'Spouse','Ration card',NULL,'No',NULL,NULL),(38130010102,NULL,38,'Yes, taken',NULL,NULL,NULL,'Self','Aadhaar card',NULL,'Yes, taken',NULL,NULL),(38130020101,NULL,38,'Yes, taken',NULL,NULL,NULL,'Self','Aadhaar card',NULL,'Yes, taken',NULL,NULL);
/*!40000 ALTER TABLE `hcMember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcVisit`
--

DROP TABLE IF EXISTS `hcVisit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcVisit` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `householdId` bigint(10) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hhVisit` varchar(100) DEFAULT NULL,
  `reasonNoPart` varchar(100) DEFAULT NULL,
  `signedConsent` varchar(100) DEFAULT NULL,
  `reasonNoConsent` varchar(100) DEFAULT NULL,
  `gps_latitude` varchar(100) DEFAULT NULL,
  `gps_longitude` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcVisit`
--

LOCK TABLES `hcVisit` WRITE;
/*!40000 ALTER TABLE `hcVisit` DISABLE KEYS */;
INSERT INTO `hcVisit` VALUES (1,381300102,NULL,'2014-06-26 13:31:22','Available',NULL,'Yes',NULL,'12.7435','17.9872'),(2,381300101,NULL,'2014-06-26 14:51:10','Available',NULL,'Yes',NULL,'12.7435','17.9872'),(3,381300102,NULL,'2014-06-26 15:07:46','Available',NULL,'Yes',NULL,'12.7435','17.9872'),(4,381300101,NULL,'2014-06-27 05:39:44','Available',NULL,'Yes',NULL,'12.7435','17.9872'),(5,381300101,NULL,'2014-06-27 05:50:20','Available',NULL,'Yes',NULL,'12.7435','17.9872'),(6,381300201,NULL,'2014-06-27 05:53:24','Available',NULL,'Yes',NULL,'12.7435','17.9872'),(7,381300201,NULL,'2014-06-27 05:55:30','Unavailable',NULL,NULL,NULL,'12.7435','17.9872'),(8,381300101,NULL,'2014-06-27 10:27:07','Available',NULL,'Yes',NULL,'12.7435','17.9872'),(9,381300103,NULL,'2014-06-27 18:59:10','Available',NULL,'Yes',NULL,'12.7435','17.9872');
/*!40000 ALTER TABLE `hcVisit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hospInf`
--

DROP TABLE IF EXISTS `hospInf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hospInf` (
  `householdId` bigint(10) NOT NULL,
  `hospStatus` varchar(100) DEFAULT NULL,
  `hospCount` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`householdId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hospInf`
--

LOCK TABLES `hospInf` WRITE;
/*!40000 ALTER TABLE `hospInf` DISABLE KEYS */;
INSERT INTO `hospInf` VALUES (381300102,'Yes','2'),(381300103,'Yes','2');
/*!40000 ALTER TABLE `hospInf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `house`
--

DROP TABLE IF EXISTS `house`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `house` (
  `houseId` bigint(10) NOT NULL,
  `areaId` bigint(10) DEFAULT NULL,
  `houseNs` varchar(100) DEFAULT NULL,
  `gps_latitude` varchar(100) DEFAULT NULL,
  `gps_longitude` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`houseId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `house`
--

LOCK TABLES `house` WRITE;
/*!40000 ALTER TABLE `house` DISABLE KEYS */;
INSERT INTO `house` VALUES (3813001,13,'12','12.7435','17.9872'),(3813002,13,'20','12.7435','17.9872'),(3813003,13,'12','12.7435','17.9872');
/*!40000 ALTER TABLE `house` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `household`
--

DROP TABLE IF EXISTS `household`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `household` (
  `householdId` bigint(10) NOT NULL,
  `houseId` bigint(10) DEFAULT NULL,
  `areaId` bigint(10) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `otherReligion` varchar(100) DEFAULT NULL,
  `nameStreet` varchar(100) DEFAULT NULL,
  `landmark` varchar(100) DEFAULT NULL,
  `mobile1` varchar(100) DEFAULT NULL,
  `mobile2` varchar(100) DEFAULT NULL,
  `secondPersonName` varchar(100) DEFAULT NULL,
  `houseNsNo2` varchar(100) DEFAULT NULL,
  `nameStreet2` varchar(100) DEFAULT NULL,
  `landmark2` varchar(100) DEFAULT NULL,
  `secondPersonMobile` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`householdId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `household`
--

LOCK TABLES `household` WRITE;
/*!40000 ALTER TABLE `household` DISABLE KEYS */;
INSERT INTO `household` VALUES (381300101,3813001,13,'Hinduism',NULL,'2dfsdf','wefwer','1111111111','1111111111','sdfsd','23','23','23','1111111111'),(381300102,3813001,13,'Jainism',NULL,'2','2','2222222222','2222222222','ram','2199','x','x','2222222222'),(381300201,3813002,13,'Hinduism',NULL,'Mahatma Gandhi Road','Near Sardar Patel Statue','9812345234','9347528390','Chaganbhai','28','Yashoda Street','Ram Mandir','8734657890'),(381300301,3813003,13,'Hinduism',NULL,'sdfsd','sdfsd','1111111111','1111111111','sdfds','12','sdf','sdf','1111111111'),(381300103,3813001,13,'Hinduism',NULL,'a','a','9999999999','','sss','134','a','a','9999999999');
/*!40000 ALTER TABLE `household` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `householdCommonQs`
--

DROP TABLE IF EXISTS `householdCommonQs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `householdCommonQs` (
  `householdId` bigint(10) NOT NULL,
  `roomCount` varchar(100) DEFAULT NULL,
  `constructionType` varchar(100) DEFAULT NULL,
  `sourceDrinkingWater` varchar(100) DEFAULT NULL,
  `cookFuel` varchar(100) DEFAULT NULL,
  `cookingPlace` varchar(100) DEFAULT NULL,
  `kitchenVentilation` varchar(100) DEFAULT NULL,
  `cookingPerson` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`householdId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `householdCommonQs`
--

LOCK TABLES `householdCommonQs` WRITE;
/*!40000 ALTER TABLE `householdCommonQs` DISABLE KEYS */;
/*!40000 ALTER TABLE `householdCommonQs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `householdDeath`
--

DROP TABLE IF EXISTS `householdDeath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `householdDeath` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `householdId` bigint(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `reasonWomenDeath` varchar(100) DEFAULT NULL,
  `age_value` varchar(100) DEFAULT NULL,
  `age_unit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `householdDeath`
--

LOCK TABLES `householdDeath` WRITE;
/*!40000 ALTER TABLE `householdDeath` DISABLE KEYS */;
INSERT INTO `householdDeath` VALUES (1,381300102,'das','Male',NULL,'20','Years'),(2,381300103,'aaa','Male',NULL,'23','Years');
/*!40000 ALTER TABLE `householdDeath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `householdFoodItems`
--

DROP TABLE IF EXISTS `householdFoodItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `householdFoodItems` (
  `householdId` bigint(10) NOT NULL,
  `onion` varchar(100) DEFAULT NULL,
  `garlic` varchar(100) DEFAULT NULL,
  `turmeric` varchar(100) DEFAULT NULL,
  `oil` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`householdId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `householdFoodItems`
--

LOCK TABLES `householdFoodItems` WRITE;
/*!40000 ALTER TABLE `householdFoodItems` DISABLE KEYS */;
INSERT INTO `householdFoodItems` VALUES (381300102,'1','1','1','12'),(381300301,'23','23','23','23'),(381300103,'1','12','1','12');
/*!40000 ALTER TABLE `householdFoodItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `householdHosp`
--

DROP TABLE IF EXISTS `householdHosp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `householdHosp` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `householdId` bigint(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `nameHospital` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `householdHosp`
--

LOCK TABLES `householdHosp` WRITE;
/*!40000 ALTER TABLE `householdHosp` DISABLE KEYS */;
INSERT INTO `householdHosp` VALUES (1,381300102,'kailash','sss','s'),(2,381300102,'kailash','sss','s'),(3,381300103,'sumi','duh','aaa'),(4,381300103,'sat','aaa','aaa');
/*!40000 ALTER TABLE `householdHosp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbox`
--

DROP TABLE IF EXISTS `inbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inbox` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `datastore` varchar(100) DEFAULT NULL,
  `ref` varchar(100) DEFAULT NULL,
  `refId` varchar(100) DEFAULT NULL,
  `distList` varchar(100) DEFAULT NULL,
  `distStatus` varchar(100) DEFAULT NULL,
  `impStatus` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbox`
--

LOCK TABLES `inbox` WRITE;
/*!40000 ALTER TABLE `inbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitationCard`
--

DROP TABLE IF EXISTS `invitationCard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invitationCard` (
  `memberId` bigint(10) NOT NULL,
  `phn` varchar(100) DEFAULT NULL,
  `rePhn` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitationCard`
--

LOCK TABLES `invitationCard` WRITE;
/*!40000 ALTER TABLE `invitationCard` DISABLE KEYS */;
INSERT INTO `invitationCard` VALUES (38130010201,'111111','111111');
/*!40000 ALTER TABLE `invitationCard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitationCardPhn`
--

DROP TABLE IF EXISTS `invitationCardPhn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invitationCardPhn` (
  `phn` varchar(100) NOT NULL,
  `barcode` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`phn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitationCardPhn`
--

LOCK TABLES `invitationCardPhn` WRITE;
/*!40000 ALTER TABLE `invitationCardPhn` DISABLE KEYS */;
/*!40000 ALTER TABLE `invitationCardPhn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `memberId` bigint(10) NOT NULL,
  `householdId` bigint(10) DEFAULT NULL,
  `houseId` bigint(10) DEFAULT NULL,
  `areaId` bigint(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `age` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (38130010101,381300101,3813001,13,'sdfsdf','Male','23'),(38130010102,381300101,3813001,13,'member new','Female','40'),(38130010201,381300102,3813001,13,'kailash','Male','50'),(38130010202,381300102,3813001,13,'kalua','Female','51'),(38130020101,381300201,3813002,13,'Renukaben','Female','58'),(38130030101,381300301,3813003,13,'sesdf','Male','45'),(38130010301,381300103,3813001,13,'sumi','Male','39'),(38130010302,381300103,3813001,13,'sat','Male','45');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberBp1`
--

DROP TABLE IF EXISTS `memberBp1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberBp1` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bp1Systolic` varchar(100) DEFAULT NULL,
  `bp1Diastolic` varchar(100) DEFAULT NULL,
  `heartrate1` varchar(100) DEFAULT NULL,
  `education` varchar(100) DEFAULT NULL,
  `mstatus` varchar(100) DEFAULT NULL,
  `noChildren` varchar(100) DEFAULT NULL,
  `childName` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberBp1`
--

LOCK TABLES `memberBp1` WRITE;
/*!40000 ALTER TABLE `memberBp1` DISABLE KEYS */;
INSERT INTO `memberBp1` VALUES (38130010201,'2014-06-26 09:34:26','2014-06-26 13:34:43','160','70','78','Illiterate','Never Married','2','ram','Agriculture labour'),(38130010101,'2014-06-26 11:00:27','2014-06-26 15:03:34','120','60','90','Below primary','Refused to Answer','2','ram','Farmers'),(38130010202,'2014-06-26 11:07:59','2014-06-26 15:08:29','120','80','110','Hr. Sec/ Class XII/ Pre-Univ','Married','1','ram','Housewife'),(38130010102,'2014-06-27 00:07:45','2014-06-26 18:27:34','120','111','90','Illiterate','Never Married','0','sdfsdf','Salaried'),(38130020101,'2014-06-27 11:27:12','2014-06-27 06:05:24','120','110','110','Below primary','Married','2','kumar','Farmers');
/*!40000 ALTER TABLE `memberBp1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberBp2`
--

DROP TABLE IF EXISTS `memberBp2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberBp2` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bp2Systolic` varchar(100) DEFAULT NULL,
  `bp2Diastolic` varchar(100) DEFAULT NULL,
  `heartrate2` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberBp2`
--

LOCK TABLES `memberBp2` WRITE;
/*!40000 ALTER TABLE `memberBp2` DISABLE KEYS */;
INSERT INTO `memberBp2` VALUES (38130010201,'2014-06-26 10:15:20','2014-06-26 14:14:51','170','80','111'),(38130020101,'2014-06-27 15:49:07','2014-06-27 10:19:17','120','110','123');
/*!40000 ALTER TABLE `memberBp2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberFamilyMedicalHistory`
--

DROP TABLE IF EXISTS `memberFamilyMedicalHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberFamilyMedicalHistory` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `motherName` varchar(100) DEFAULT NULL,
  `motherState` varchar(100) DEFAULT NULL,
  `motherdistrict` varchar(100) DEFAULT NULL,
  `motherCaste` varchar(100) DEFAULT NULL,
  `otherCasteMother` varchar(100) DEFAULT NULL,
  `motherTongue` varchar(100) DEFAULT NULL,
  `htnMother` varchar(100) DEFAULT NULL,
  `dmMother` varchar(100) DEFAULT NULL,
  `asthmaMother` varchar(100) DEFAULT NULL,
  `hdMother` varchar(100) DEFAULT NULL,
  `cancerMother` varchar(100) DEFAULT NULL,
  `locationCancerMother` varchar(100) DEFAULT NULL,
  `otherCancerMother` varchar(100) DEFAULT NULL,
  `htnFather` varchar(100) DEFAULT NULL,
  `dmFather` varchar(100) DEFAULT NULL,
  `asthmaFather` varchar(100) DEFAULT NULL,
  `hdFather` varchar(100) DEFAULT NULL,
  `cancerFather` varchar(100) DEFAULT NULL,
  `locationCancerFather` varchar(100) DEFAULT NULL,
  `otherCancerFather` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberFamilyMedicalHistory`
--

LOCK TABLES `memberFamilyMedicalHistory` WRITE;
/*!40000 ALTER TABLE `memberFamilyMedicalHistory` DISABLE KEYS */;
INSERT INTO `memberFamilyMedicalHistory` VALUES (38130010201,'2014-06-26 10:10:36','2014-06-26 14:12:12','ramya','Mizoram (MZ)','Fatehgarh Sahib','Lingayat',NULL,'Marathi','Yes, taken','Not taken','Yes','No','Yes',NULL,NULL,'No','Yes, on medications','Yes, on medications','Yes, on medications','No',NULL,NULL),(38130010202,'2014-06-26 11:14:14','2014-06-26 15:26:54','kavita','Goa (GA)','Karimnagar','Dhangar',NULL,'Bhili/Bhilodi','No','No','No','No','No',NULL,NULL,'No','No','No','No','No',NULL,NULL),(38130020101,'2014-06-27 15:15:36','2014-06-27 09:47:10','sdfsd','Tamil Nadu (TN)','Salem','Brahman',NULL,'Tamil','Yes, taken','Yes, taken','Yes, taken','Yes, taken','Yes, taken',NULL,NULL,'No','No','No','No','No',NULL,NULL);
/*!40000 ALTER TABLE `memberFamilyMedicalHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberImage`
--

DROP TABLE IF EXISTS `memberImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberImage` (
  `memberId` bigint(10) NOT NULL,
  `consent` varchar(100) DEFAULT NULL,
  `photoId` varchar(100) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberImage`
--

LOCK TABLES `memberImage` WRITE;
/*!40000 ALTER TABLE `memberImage` DISABLE KEYS */;
INSERT INTO `memberImage` VALUES (38130020101,'38130020101_consent',NULL,NULL);
/*!40000 ALTER TABLE `memberImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberPersonalMedicalHistory`
--

DROP TABLE IF EXISTS `memberPersonalMedicalHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberPersonalMedicalHistory` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rateHealthStatus` varchar(100) DEFAULT NULL,
  `htn` varchar(100) DEFAULT NULL,
  `ageHtn` varchar(100) DEFAULT NULL,
  `dm` varchar(100) DEFAULT NULL,
  `ageDm` varchar(100) DEFAULT NULL,
  `hd` varchar(100) DEFAULT NULL,
  `ageHd` varchar(100) DEFAULT NULL,
  `stroke` varchar(100) DEFAULT NULL,
  `ageStroke` varchar(100) DEFAULT NULL,
  `tb` varchar(100) DEFAULT NULL,
  `ageTb` varchar(100) DEFAULT NULL,
  `asthma` varchar(100) DEFAULT NULL,
  `ageAsthma` varchar(100) DEFAULT NULL,
  `cancer` varchar(100) DEFAULT NULL,
  `ageCancer` varchar(100) DEFAULT NULL,
  `locationCancerMale` varchar(100) DEFAULT NULL,
  `locationCancerFemale` varchar(100) DEFAULT NULL,
  `otherCancer` varchar(100) DEFAULT NULL,
  `whitepatchMouth` varchar(100) DEFAULT NULL,
  `redpatchMouth` varchar(100) DEFAULT NULL,
  `ageMenarche` varchar(100) DEFAULT NULL,
  `pregnantCurrent` varchar(100) DEFAULT NULL,
  `pregnantPast` varchar(100) DEFAULT NULL,
  `noTimesPregnantPast` varchar(100) DEFAULT NULL,
  `age1stPregnant` varchar(100) DEFAULT NULL,
  `outcome1stPregnant` varchar(100) DEFAULT NULL,
  `bf1stBaby` varchar(100) DEFAULT NULL,
  `nomnths1stBf` varchar(100) DEFAULT NULL,
  `age2ndPregnant` varchar(100) DEFAULT NULL,
  `outcome2ndPregnant` varchar(100) DEFAULT NULL,
  `bf2ndBaby` varchar(100) DEFAULT NULL,
  `nomnths2ndBf` varchar(100) DEFAULT NULL,
  `age3rdPregnant` varchar(100) DEFAULT NULL,
  `outcome3rdPregnant` varchar(100) DEFAULT NULL,
  `bf3rdBaby` varchar(100) DEFAULT NULL,
  `nomnths3rdBf` varchar(100) DEFAULT NULL,
  `age4thPregnant` varchar(100) DEFAULT NULL,
  `outcome4thPregnant` varchar(100) DEFAULT NULL,
  `bf4thBaby` varchar(100) DEFAULT NULL,
  `nomnths4thBf` varchar(100) DEFAULT NULL,
  `contraceptives` varchar(100) DEFAULT NULL,
  `othersContraceptives` varchar(100) DEFAULT NULL,
  `periodsStatus` varchar(100) DEFAULT NULL,
  `ageStopPeriods` varchar(100) DEFAULT NULL,
  `ageMenopause` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberPersonalMedicalHistory`
--

LOCK TABLES `memberPersonalMedicalHistory` WRITE;
/*!40000 ALTER TABLE `memberPersonalMedicalHistory` DISABLE KEYS */;
INSERT INTO `memberPersonalMedicalHistory` VALUES (38130010201,'2014-06-26 10:09:58','2014-06-26 14:09:58','Excellent','Yes, on medications','5','No',NULL,'No',NULL,'Unknown',NULL,'Yes, but not on medications','5','Unknown',NULL,'Yes, on medications','5','Oesophagus',NULL,NULL,'No','No',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38130010202,'2014-06-26 11:11:30','2014-06-26 15:14:14','Excellent','No',NULL,'No',NULL,'No',NULL,'No',NULL,'No',NULL,'Yes, but not on medications','0','Yes, on medications','1',NULL,'Breast',NULL,'No','No',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38130010102,'2014-06-27 00:25:51','2014-06-26 18:57:45','Excellent','No',NULL,'No',NULL,'No',NULL,'No',NULL,'No',NULL,'No',NULL,'No',NULL,NULL,NULL,NULL,'Yes','Yes','12','Yes','Yes','2','14','Baby was born alive','Yes','12','11','Baby was born alive','Yes','23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'None',NULL,'No','34',NULL),(38130020101,'2014-06-27 14:59:55','2014-06-27 09:45:35','Excellent','No',NULL,'No',NULL,'No',NULL,'No',NULL,'No',NULL,'No',NULL,'No',NULL,NULL,NULL,NULL,'Yes','Yes',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `memberPersonalMedicalHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberPhysicalActivities`
--

DROP TABLE IF EXISTS `memberPhysicalActivities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberPhysicalActivities` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `servantHh` varchar(100) DEFAULT NULL,
  `servantParttime` varchar(100) DEFAULT NULL,
  `servantFulltime` varchar(100) DEFAULT NULL,
  `hhMaintanence` varchar(100) DEFAULT NULL,
  `cooking` varchar(100) DEFAULT NULL,
  `walking` varchar(100) DEFAULT NULL,
  `cycling` varchar(100) DEFAULT NULL,
  `takingcare` varchar(100) DEFAULT NULL,
  `carryingwater` varchar(100) DEFAULT NULL,
  `othersActivity` varchar(100) DEFAULT NULL,
  `othersSpecify` varchar(100) DEFAULT NULL,
  `othersActivityTime` varchar(100) DEFAULT NULL,
  `hrsSleepNight` varchar(100) DEFAULT NULL,
  `hrsSleepDaylight` varchar(100) DEFAULT NULL,
  `hrsSleepAfterEat` varchar(100) DEFAULT NULL,
  `hrsWatchtvDay` varchar(100) DEFAULT NULL,
  `hrsWatchtvHoliday` varchar(100) DEFAULT NULL,
  `sportsExsCurrent` varchar(100) DEFAULT NULL,
  `sportExs1` varchar(100) DEFAULT NULL,
  `ageStartSportExs1` varchar(100) DEFAULT NULL,
  `timeSportExs1Wk` varchar(100) DEFAULT NULL,
  `sportExs2` varchar(100) DEFAULT NULL,
  `ageStartSportExs2` varchar(100) DEFAULT NULL,
  `timeSportExs2Wk` varchar(100) DEFAULT NULL,
  `otherSportsExs` varchar(100) DEFAULT NULL,
  `sportsExsPast` varchar(100) DEFAULT NULL,
  `sportExs1Past` varchar(100) DEFAULT NULL,
  `ageStartSportExs1Past` varchar(100) DEFAULT NULL,
  `ageStopSportExs1` varchar(100) DEFAULT NULL,
  `timeSportExs1WkPast` varchar(100) DEFAULT NULL,
  `sportExs2Past` varchar(100) DEFAULT NULL,
  `ageStartSportExs2Past` varchar(100) DEFAULT NULL,
  `ageStopSportExs2` varchar(100) DEFAULT NULL,
  `timeSportExs2WkPast` varchar(100) DEFAULT NULL,
  `otherSportsExsPast` varchar(100) DEFAULT NULL,
  `nowMale` varchar(100) DEFAULT NULL,
  `ageTwentyMale` varchar(100) DEFAULT NULL,
  `ageTenMale` varchar(100) DEFAULT NULL,
  `nowFemale` varchar(100) DEFAULT NULL,
  `ageTwentyFemale` varchar(100) DEFAULT NULL,
  `ageTenFemale` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberPhysicalActivities`
--

LOCK TABLES `memberPhysicalActivities` WRITE;
/*!40000 ALTER TABLE `memberPhysicalActivities` DISABLE KEYS */;
INSERT INTO `memberPhysicalActivities` VALUES (38130010201,'2014-06-26 10:12:50','2014-06-26 14:14:42','No',NULL,NULL,'0.5','1.5','2.5','8.5','1','0.5','Yes','jumping','0.5','6','3.5','7.5','8','8.5','Yes','Gymnastics','12','2',NULL,'12','9',NULL,'No',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3','3','3',NULL,NULL,NULL),(38130010202,'2014-06-26 11:26:54','2014-06-26 15:29:48','No',NULL,NULL,'7.5','7.5','7.5','8','8.5','8','Yes','ff','8','9','8.5','8','7.5','8','Yes','Gajge','1','12',NULL,'2','23',NULL,'No',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2','2','3'),(38130020101,'2014-06-27 15:17:11','2014-06-27 10:19:06','Yes','1','1','3','2','0',NULL,NULL,NULL,'Yes','sdfsd','0','0','2','0','0','1.5','Yes','Aerobics','12','12','Aerobics','12','12',NULL,'Yes','Andhala topi','12','12','12','Atayapataya','12','12','12',NULL,NULL,NULL,NULL,'4','1','1');
/*!40000 ALTER TABLE `memberPhysicalActivities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberTobaccoAlcohol`
--

DROP TABLE IF EXISTS `memberTobaccoAlcohol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberTobaccoAlcohol` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `smokeTobacco` varchar(100) DEFAULT NULL,
  `ageStartSmokeCurrent` varchar(100) DEFAULT NULL,
  `freqCigarettesDay` varchar(100) DEFAULT NULL,
  `freqCigarettesWeek` varchar(100) DEFAULT NULL,
  `freqBidisDay` varchar(100) DEFAULT NULL,
  `freqBidisWeek` varchar(100) DEFAULT NULL,
  `freqOtherTobaccoDay` varchar(100) DEFAULT NULL,
  `freqOtherTobaccoWeek` varchar(100) DEFAULT NULL,
  `smokeTobaccoPast` varchar(100) DEFAULT NULL,
  `ageStartSmokingPast` varchar(100) DEFAULT NULL,
  `ageStopSmokingPast` varchar(100) DEFAULT NULL,
  `reasonStopSmoking` varchar(100) DEFAULT NULL,
  `smokelessTobacco` varchar(100) DEFAULT NULL,
  `ageSmokelessTobaccoCurrent` varchar(100) DEFAULT NULL,
  `freqChewTobaccoDay` varchar(100) DEFAULT NULL,
  `freqChewTobaccoWeek` varchar(100) DEFAULT NULL,
  `freqKhainiLimemixDay` varchar(100) DEFAULT NULL,
  `freqKhainiLimemixWeek` varchar(100) DEFAULT NULL,
  `freqGhutkaDay` varchar(100) DEFAULT NULL,
  `freqGhutkaWeek` varchar(100) DEFAULT NULL,
  `freqOralTobaccoDay` varchar(100) DEFAULT NULL,
  `freqOralTobaccoWeek` varchar(100) DEFAULT NULL,
  `freqPanmasalaBetelquidDay` varchar(100) DEFAULT NULL,
  `freqPanmasalaBetelquidWeek` varchar(100) DEFAULT NULL,
  `freqNasalSnuffDay` varchar(100) DEFAULT NULL,
  `freqNasalSnuffWeek` varchar(100) DEFAULT NULL,
  `freqOtherSmokelessTobaccoDay` varchar(100) DEFAULT NULL,
  `freqOtherSmokelessTobaccoWeek` varchar(100) DEFAULT NULL,
  `smokelessTobaccoPast` varchar(100) DEFAULT NULL,
  `ageStartSmokelessTobaccoPast` varchar(100) DEFAULT NULL,
  `ageStopSmokelessTobaccoPast` varchar(100) DEFAULT NULL,
  `reasonStopSmokelessTobacco` varchar(100) DEFAULT NULL,
  `consumeAlcohol` varchar(100) DEFAULT NULL,
  `ageStartDrinkingCurrent` varchar(100) DEFAULT NULL,
  `freqCountryliquor` varchar(100) DEFAULT NULL,
  `freqSprit` varchar(100) DEFAULT NULL,
  `freqBeer` varchar(100) DEFAULT NULL,
  `freqWine` varchar(100) DEFAULT NULL,
  `alcoholPast` varchar(100) DEFAULT NULL,
  `ageStartAlcoholPast` varchar(100) DEFAULT NULL,
  `ageStopAlcoholPast` varchar(100) DEFAULT NULL,
  `reasonStopAlcohol` varchar(100) DEFAULT NULL,
  `drinkStatusHusband` varchar(100) DEFAULT NULL,
  `freqDrinkHusband` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberTobaccoAlcohol`
--

LOCK TABLES `memberTobaccoAlcohol` WRITE;
/*!40000 ALTER TABLE `memberTobaccoAlcohol` DISABLE KEYS */;
INSERT INTO `memberTobaccoAlcohol` VALUES (38130010201,'2014-06-26 10:07:13','2014-06-26 14:09:04','Daily','12','12',NULL,'0',NULL,'0',NULL,NULL,NULL,NULL,NULL,'Less than daily','2',NULL,'2',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,NULL,NULL,NULL,'Yes','7','4','5','0','0',NULL,NULL,NULL,NULL,NULL,NULL),(38130010101,'2014-06-26 11:03:34','2014-06-26 15:06:59','Refused to answer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Daily','1','2',NULL,'2',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,'0',NULL,NULL,NULL,NULL,NULL,'Yes','0','2','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL),(38130010202,'2014-06-26 11:08:29','2014-06-26 15:11:30','Daily','0','0',NULL,'0',NULL,'00',NULL,NULL,NULL,NULL,NULL,'Refused to answer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Yes','0','0','0','0','0',NULL,NULL,NULL,NULL,'Does not drink much (occasional drinker)','7'),(38130020101,'2014-06-27 11:35:24','2014-06-27 06:58:06','Daily','12','12',NULL,'12',NULL,'12',NULL,NULL,NULL,NULL,NULL,'Daily','12','12',NULL,'12',NULL,'12',NULL,'1',NULL,'1',NULL,'1',NULL,'1',NULL,NULL,NULL,NULL,NULL,'Yes','12','3','1','1','1',NULL,NULL,NULL,NULL,'Does not drink at all',NULL),(38130010301,'2014-06-27 15:10:37','2014-06-27 19:11:51','Daily','12','2',NULL,'0',NULL,'0',NULL,NULL,NULL,NULL,NULL,'Not at all',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'No',NULL,NULL,NULL,'Yes','12','1','0','0','0',NULL,NULL,NULL,NULL,'Does not drink much (occasional drinker)','6');
/*!40000 ALTER TABLE `memberTobaccoAlcohol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbox`
--

DROP TABLE IF EXISTS `outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outbox` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `datastore` varchar(100) DEFAULT NULL,
  `ref` varchar(100) DEFAULT NULL,
  `refId` varchar(100) DEFAULT NULL,
  `recipient` bigint(10) DEFAULT NULL,
  `distList` varchar(100) DEFAULT NULL,
  `dwnStatus` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbox`
--

LOCK TABLES `outbox` WRITE;
/*!40000 ALTER TABLE `outbox` DISABLE KEYS */;
INSERT INTO `outbox` VALUES (1,'area','areaId','13',15,'','1'),(2,'house','areaId','13',15,'','1'),(3,'household','areaId','13',15,'','1'),(4,'member','areaId','13',15,'','1'),(5,'area','areaId','13',15,'','1'),(6,'house','areaId','13',15,'','1'),(7,'household','areaId','13',15,'','1'),(8,'member','areaId','13',15,'','1'),(9,'area','areaId','13',15,'','1'),(10,'house','areaId','13',15,'','1'),(11,'household','areaId','13',15,'','1'),(12,'member','areaId','13',15,'','1'),(13,'area','areaId','13',15,'','1'),(14,'house','areaId','13',15,'','1'),(15,'household','areaId','13',15,'','1'),(16,'member','areaId','13',15,'','1'),(17,'area','areaId','13',15,'',NULL),(18,'house','areaId','13',15,'',NULL),(19,'household','areaId','13',15,'',NULL),(20,'member','areaId','13',15,'',NULL);
/*!40000 ALTER TABLE `outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resampAssign`
--

DROP TABLE IF EXISTS `resampAssign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resampAssign` (
  `memberId` bigint(10) NOT NULL,
  `user` varchar(100) DEFAULT NULL,
  `timelog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resampAssign`
--

LOCK TABLES `resampAssign` WRITE;
/*!40000 ALTER TABLE `resampAssign` DISABLE KEYS */;
/*!40000 ALTER TABLE `resampAssign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resampling`
--

DROP TABLE IF EXISTS `resampling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resampling` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `education` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `smokeTobacco` varchar(100) DEFAULT NULL,
  `smokelessTobacco` varchar(100) DEFAULT NULL,
  `consumeAlcohol` varchar(100) DEFAULT NULL,
  `motherCaste` varchar(100) DEFAULT NULL,
  `motherTongue` varchar(100) DEFAULT NULL,
  `htnMother` varchar(100) DEFAULT NULL,
  `dmMother` varchar(100) DEFAULT NULL,
  `asthmaMother` varchar(100) DEFAULT NULL,
  `hdMother` varchar(100) DEFAULT NULL,
  `cancerMother` varchar(100) DEFAULT NULL,
  `htnFather` varchar(100) DEFAULT NULL,
  `dmFather` varchar(100) DEFAULT NULL,
  `asthmaFather` varchar(100) DEFAULT NULL,
  `hdFather` varchar(100) DEFAULT NULL,
  `cancerFather` varchar(100) DEFAULT NULL,
  `servantHh` varchar(100) DEFAULT NULL,
  `sportsExsCurrent` varchar(100) DEFAULT NULL,
  `typeFood` varchar(100) DEFAULT NULL,
  `veg` varchar(100) DEFAULT NULL,
  `nonveg` varchar(100) DEFAULT NULL,
  `fastStatus` varchar(100) DEFAULT NULL,
  `benefitGovtScheme` varchar(100) DEFAULT NULL,
  `roomCount` varchar(100) DEFAULT NULL,
  `cookingPlace` varchar(100) DEFAULT NULL,
  `kitchenVentilation` varchar(100) DEFAULT NULL,
  `cookingPerson` varchar(100) DEFAULT NULL,
  `hospitalization` varchar(100) DEFAULT NULL,
  `deathHhmem` varchar(100) DEFAULT NULL,
  `htn` varchar(100) DEFAULT NULL,
  `dm` varchar(100) DEFAULT NULL,
  `hd` varchar(100) DEFAULT NULL,
  `stroke` varchar(100) DEFAULT NULL,
  `tb` varchar(100) DEFAULT NULL,
  `asthma` varchar(100) DEFAULT NULL,
  `cancer` varchar(100) DEFAULT NULL,
  `rateHealthStatus` varchar(100) DEFAULT NULL,
  `relationshipHeadFamily` varchar(100) DEFAULT NULL,
  `mstatus` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resampling`
--

LOCK TABLES `resampling` WRITE;
/*!40000 ALTER TABLE `resampling` DISABLE KEYS */;
/*!40000 ALTER TABLE `resampling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `id` bigint(10) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (1,'Team A');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teamuser`
--

DROP TABLE IF EXISTS `teamuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teamuser` (
  `teamId` bigint(10) DEFAULT NULL,
  `userId` bigint(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teamuser`
--

LOCK TABLES `teamuser` WRITE;
/*!40000 ALTER TABLE `teamuser` DISABLE KEYS */;
INSERT INTO `teamuser` VALUES (1,15);
/*!40000 ALTER TABLE `teamuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(10) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (15,'kiran','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'manager'),(16,'harsha','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(17,'lingraj','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(18,'seeta','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(19,'tambe','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(30,'sujata','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(31,'senthil','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(32,'ravi','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(33,'sagar','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(34,'srinivas','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(35,'anuradha','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(36,'bipin','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(37,'panse','5f4dcc3b5aa765d61d8327deb882cf99',NULL,'user'),(38,'demo','fe01ce2a7fbac8fafaed7c982a04e229',NULL,'user');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userlog`
--

DROP TABLE IF EXISTS `userlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userlog` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `time` varchar(100) DEFAULT NULL,
  `ipaddress` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userlog`
--

LOCK TABLES `userlog` WRITE;
/*!40000 ALTER TABLE `userlog` DISABLE KEYS */;
INSERT INTO `userlog` VALUES (1,'kiran','success',NULL,NULL),(2,'demo','success',NULL,NULL),(3,'demo','success',NULL,NULL),(4,'demo','success',NULL,NULL),(5,'demo','success',NULL,NULL),(6,'demo','success',NULL,NULL),(7,'demo','success',NULL,NULL),(8,'demo','success',NULL,NULL),(9,'demo','success',NULL,NULL),(10,'demo','success',NULL,NULL),(11,'demo','success',NULL,NULL),(12,'demo','success',NULL,NULL),(13,'demo','success',NULL,NULL),(14,'demo','success',NULL,NULL),(15,'demo','success',NULL,NULL),(16,'demo','success',NULL,NULL),(17,'demo','success',NULL,NULL),(18,'demo','success',NULL,NULL),(19,'demo','success',NULL,NULL),(20,'demo','success',NULL,NULL),(21,'demo','success',NULL,NULL),(22,'kiran','success',NULL,NULL),(23,'kiran','success',NULL,NULL),(24,'kiran','success',NULL,NULL),(25,'kiran','success',NULL,NULL),(26,'demo','success',NULL,NULL),(27,'kiran','success',NULL,NULL),(28,'demo','success',NULL,NULL),(29,'demo','success',NULL,NULL),(30,'demo','success',NULL,NULL),(31,'kiran','success',NULL,NULL),(32,'kiran','success',NULL,NULL),(33,'kiran','success',NULL,NULL),(34,'kiran','success',NULL,NULL),(35,'kiran','success',NULL,NULL),(36,'kiran','success',NULL,NULL),(37,'kiran','success',NULL,NULL),(38,'kiran','success',NULL,NULL),(39,'kiran','success',NULL,NULL),(40,'kiran','success',NULL,NULL),(41,'kiran','success',NULL,NULL),(42,'kiran','success',NULL,NULL),(43,'kiran','success',NULL,NULL),(44,'kiran','success',NULL,NULL),(45,'demo','success',NULL,NULL),(46,'demo','success',NULL,NULL);
/*!40000 ALTER TABLE `userlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wrkstn1`
--

DROP TABLE IF EXISTS `wrkstn1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wrkstn1` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `wristBand` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wrkstn1`
--

LOCK TABLES `wrkstn1` WRITE;
/*!40000 ALTER TABLE `wrkstn1` DISABLE KEYS */;
INSERT INTO `wrkstn1` VALUES (100010101,'2014-05-22 10:15:49','2014-05-26 04:34:47','00003000045'),(100230101,'2014-05-22 08:20:02','2014-05-26 04:34:47','00003000065'),(100030103,'2014-05-22 07:39:21','2014-05-26 04:34:52','00003000042'),(100150101,'2014-05-22 07:40:44','2014-05-26 04:34:52','00003000012'),(100020102,'2014-05-22 07:55:38','2014-05-26 04:34:52','00003000026'),(100100101,'2014-05-22 08:01:28','2014-05-26 04:34:52','00003000041'),(100130102,'2014-05-22 08:06:04','2014-05-26 04:34:52','00003000003'),(100120101,'2014-05-22 08:11:52','2014-05-26 04:34:52','00003000061'),(100090102,'2014-05-22 08:15:18','2014-05-26 04:34:52','00003000063'),(100090103,'2014-05-22 08:26:05','2014-05-26 04:34:52','00003000064'),(100150102,'2014-05-22 08:34:31','2014-05-26 04:34:52','00003000062'),(100140101,'2014-05-22 08:41:23','2014-05-26 04:35:05','00003000044'),(100120102,'2014-05-22 08:48:00','2014-05-26 04:35:05','00003000043'),(100050102,'2014-05-22 08:55:43','2014-05-26 04:35:05','00003000038'),(100100102,'2014-05-22 09:02:39','2014-05-26 04:35:05','00003000049'),(100060102,'2014-05-22 09:10:37','2014-05-26 04:35:06','00003000019'),(100240102,'2014-05-22 09:16:58','2014-05-26 04:35:06','00003000051'),(100210102,'2014-05-22 09:22:42','2014-05-26 04:35:06','00003000050'),(100160202,'2014-05-22 09:29:24','2014-05-26 04:35:59','00003000053'),(100070101,'2014-05-22 09:36:21','2014-05-26 04:35:59','00003000052'),(100240101,'2014-05-22 09:45:15','2014-05-26 04:35:59','00003000027'),(100020101,'2014-05-22 09:56:47','2014-05-26 04:35:59','00003000017'),(100260102,'2014-05-22 10:05:41','2014-05-26 04:39:48','00003000016'),(100260101,'2014-05-22 10:20:52','2014-05-26 04:39:48','00003000048'),(100010102,'2014-05-22 10:27:58','2014-05-26 04:39:48','00003000021'),(100070102,'2014-05-22 10:34:41','2014-05-26 04:39:52','00003000037');
/*!40000 ALTER TABLE `wrkstn1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wrkstn2`
--

DROP TABLE IF EXISTS `wrkstn2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wrkstn2` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bpSystolic` varchar(100) DEFAULT NULL,
  `bpDiastolic` varchar(100) DEFAULT NULL,
  `heartrate` varchar(100) DEFAULT NULL,
  `indexFingerLength` varchar(100) DEFAULT NULL,
  `skipIndexFingerLength` varchar(100) DEFAULT NULL,
  `ringFingerLength` varchar(100) DEFAULT NULL,
  `skipRingFingerLength` varchar(100) DEFAULT NULL,
  `rightGripStrength` varchar(100) DEFAULT NULL,
  `skipRtHandGrip` varchar(100) DEFAULT NULL,
  `leftGripStrength` varchar(100) DEFAULT NULL,
  `skipLtHandGrip` varchar(100) DEFAULT NULL,
  `sittingHeight` varchar(100) DEFAULT NULL,
  `skipSittingHeight` varchar(100) DEFAULT NULL,
  `standingHeight` varchar(100) DEFAULT NULL,
  `skipStandingHeight` varchar(100) DEFAULT NULL,
  `waistCircumference` varchar(100) DEFAULT NULL,
  `skipWaistCircumference` varchar(100) DEFAULT NULL,
  `hipCircumference` varchar(100) DEFAULT NULL,
  `skipHipCircumference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wrkstn2`
--

LOCK TABLES `wrkstn2` WRITE;
/*!40000 ALTER TABLE `wrkstn2` DISABLE KEYS */;
INSERT INTO `wrkstn2` VALUES (100230101,'2014-05-22 10:03:34','2014-05-26 04:34:47','119','85','85','6.5',NULL,'6.9',NULL,'28',NULL,'28',NULL,'122.1',NULL,'159.5',NULL,'73',NULL,'86',NULL),(100010101,'2014-05-22 11:59:13','2014-05-26 04:34:48','132','68','83','7',NULL,'6.9',NULL,'38',NULL,'36',NULL,'122',NULL,'158.3',NULL,'88',NULL,'91',NULL),(100030103,'2014-05-22 09:17:09','2014-05-26 04:34:52','123','80','70','7.5',NULL,'7.6',NULL,'23',NULL,'22',NULL,'133.5',NULL,'168',NULL,'86.7',NULL,'95.5',NULL),(100150101,'2014-05-22 09:26:46','2014-05-26 04:34:52','132','89','66','8',NULL,'8.2',NULL,'30',NULL,'40',NULL,'129.5',NULL,'182.2',NULL,'100',NULL,'101',NULL),(100020102,'2014-05-22 09:37:31','2014-05-26 04:34:52','121','72','77','7',NULL,'6.6',NULL,'32',NULL,'29',NULL,'122',NULL,'158.5',NULL,'74',NULL,'84.5',NULL),(100100101,'2014-05-22 09:43:05','2014-05-26 04:34:52','129','80','70','7.5',NULL,'7.8',NULL,'22',NULL,'22',NULL,'135.6',NULL,'167.9',NULL,'89',NULL,'90',NULL),(100130102,'2014-05-22 09:48:17','2014-05-26 04:34:52','124','76','67','7.4',NULL,'7.7',NULL,'32',NULL,'32',NULL,'123.5',NULL,'167.5',NULL,'80',NULL,'88',NULL),(100120101,'2014-05-22 09:52:29','2014-05-26 04:34:52','124','77','50','7.4',NULL,'7.6',NULL,'24',NULL,'22',NULL,'121.3',NULL,'167.5',NULL,'60.5',NULL,'82',NULL),(100090102,'2014-05-22 09:57:01','2014-05-26 04:34:52','170','80','73','7',NULL,'7.2',NULL,'40',NULL,'42',NULL,'119.5',NULL,'160',NULL,'83',NULL,'90.5',NULL),(100090103,'2014-05-22 10:11:31','2014-05-26 04:34:52','133','97','82','5.9',NULL,'6',NULL,'24',NULL,'22',NULL,'110.9',NULL,'144.9',NULL,'59',NULL,'83.5',NULL),(100150102,'2014-05-22 10:18:34','2014-05-26 04:35:05','129','83','62','7.1',NULL,'7.2',NULL,'28',NULL,'30',NULL,'118.4',NULL,'153.5',NULL,'74',NULL,'95',NULL),(100140101,'2014-05-22 10:25:00','2014-05-26 04:35:05','130','78','80','5.8',NULL,'6',NULL,'26',NULL,'23',NULL,'113',NULL,'148.7',NULL,'60',NULL,'86.4',NULL),(100120102,'2014-05-22 10:32:44','2014-05-26 04:35:05','126','77','76','6.2',NULL,'6',NULL,'20',NULL,'19',NULL,'112',NULL,'148',NULL,'62',NULL,'84.5',NULL),(100050102,'2014-05-22 10:40:06','2014-05-26 04:35:06','135','94','100','6.8',NULL,'7.1',NULL,'26',NULL,'26',NULL,'117.5',NULL,'155',NULL,'89',NULL,'114.5',NULL),(100100102,'2014-05-22 10:46:41','2014-05-26 04:35:06','117','67','90','7.2',NULL,'7.4',NULL,'28',NULL,'28',NULL,'117',NULL,'154.5',NULL,'69',NULL,'89',NULL),(100060102,'2014-05-22 10:53:30','2014-05-26 04:35:06','142','88','73','5.8',NULL,'5.6',NULL,'24',NULL,'22',NULL,'111',NULL,'143.6',NULL,'59',NULL,'82.5',NULL),(100240102,'2014-05-22 10:59:24','2014-05-26 04:35:06','134','84','91','6',NULL,'6.2',NULL,'26',NULL,'26',NULL,'113.2',NULL,'147.1',NULL,'73.5',NULL,'92.5',NULL),(100210102,'2014-05-22 11:06:47','2014-05-26 04:35:59','194','92','103','6.2',NULL,'6.7',NULL,'22',NULL,'20',NULL,'112.5',NULL,'148.6',NULL,'77',NULL,'90',NULL),(100160202,'2014-05-22 11:13:14','2014-05-26 04:35:59','101','71','80','6',NULL,'6.2',NULL,'18',NULL,'18',NULL,'113.4',NULL,'146.4',NULL,'69',NULL,'88',NULL),(100070101,'2014-05-22 11:22:29','2014-05-26 04:35:59','102','67','82','7',NULL,'7.1',NULL,'30',NULL,'26',NULL,'125',NULL,'167',NULL,'77',NULL,'88',NULL),(100240101,'2014-05-22 11:32:23','2014-05-26 04:35:59','151','100','69','6.6',NULL,'6.8',NULL,'28',NULL,'30',NULL,'121.3',NULL,'161.3',NULL,'79',NULL,'91',NULL),(100020101,'2014-05-22 11:42:53','2014-05-26 04:39:48','102','64','82','7.5',NULL,'7.8',NULL,'32',NULL,'32',NULL,'123.7',NULL,'168.5',NULL,'62',NULL,'82',NULL),(100260102,'2014-05-22 11:50:19','2014-05-26 04:39:48','129','113','93','6.6',NULL,'7.1',NULL,'22',NULL,'22',NULL,'116.6',NULL,'153.7',NULL,'79',NULL,'89',NULL),(100260101,'2014-05-22 12:05:27','2014-05-26 04:39:48','118','80','92','6.6',NULL,'6.8',NULL,'32',NULL,'36',NULL,'116.7',NULL,'156.9',NULL,'81',NULL,'89',NULL),(100010102,'2014-05-22 12:11:49','2014-05-26 04:39:52','128','91','111','5.9',NULL,'6.1',NULL,'24',NULL,'24',NULL,'117.2',NULL,'147.9',NULL,'80',NULL,'96',NULL),(100070102,'2014-05-22 12:17:05','2014-05-26 04:39:52','119','68','79','6.7',NULL,'6.9',NULL,'22',NULL,'26',NULL,'114',NULL,'154.2',NULL,'57',NULL,'78',NULL);
/*!40000 ALTER TABLE `wrkstn2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wrkstn3`
--

DROP TABLE IF EXISTS `wrkstn3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wrkstn3` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `WEIGHT` varchar(100) DEFAULT NULL,
  `CLOTHES` varchar(100) DEFAULT NULL,
  `BMI` varchar(100) DEFAULT NULL,
  `FATP` varchar(100) DEFAULT NULL,
  `TBW` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wrkstn3`
--

LOCK TABLES `wrkstn3` WRITE;
/*!40000 ALTER TABLE `wrkstn3` DISABLE KEYS */;
INSERT INTO `wrkstn3` VALUES (100230101,'2014-05-22 10:24:57','2014-05-26 04:34:47','55.1','1','21.5','17.7','31'),(100010101,'2014-05-22 12:16:59','2014-05-26 04:34:48','66.9','1','26.8','25.3','36.1'),(100030103,'2014-05-22 09:41:03','2014-05-26 04:34:52','67.8','0','24.0','23.7%','35.2'),(100150101,'2014-05-22 09:49:24','2014-05-26 04:34:52','89.6','0','27','25%','48.1'),(100020102,'2014-05-22 09:55:12','2014-05-26 04:34:52','51.8','0','20.5','17.6','28.7'),(100100101,'2014-05-22 10:00:24','2014-05-26 04:34:52','69.1','1','24.5','22.2','38.6'),(100130102,'2014-05-22 10:04:42','2014-05-26 04:34:52','61.1','0','21.6','19.4%','33'),(100120101,'2014-05-22 10:09:17','2014-05-26 04:34:52','43.9','1','15.6','3.1','28.5'),(100090102,'2014-05-22 10:14:57','2014-05-26 04:34:52','60.3','1','23.6','22.9','32.1'),(100090103,'2014-05-22 10:30:32','2014-05-26 04:35:05','37.2','1','17.7','24.4','19.7'),(100150102,'2014-05-22 10:36:53','2014-05-26 04:35:05','57.8','1','24.4','35.1','26.9'),(100140101,'2014-05-22 10:44:53','2014-05-26 04:35:05','41.7','1','18.8','27.5','21.1'),(100120102,'2014-05-22 10:52:07','2014-05-26 04:35:06','39.3','1','17.9','27.5','19.8'),(100050102,'2014-05-22 10:58:47','2014-05-26 04:35:06','74.1','1','30.8','43.8','30.4'),(100100102,'2014-05-22 11:05:41','2014-05-26 04:35:06','49.2','1','20.5','31.8','23.1\\'),(100060102,'2014-05-22 11:11:28','2014-05-26 04:35:06','37.6','1','18.1','27.1','19.4'),(100240102,'2014-05-22 11:18:39','2014-05-26 04:35:59','55.7','1','25.8','36.7','25.8'),(100210102,'2014-05-22 11:30:01','2014-05-26 04:35:59','51.2','1','23.1','35.6','23.6'),(100160202,'2014-05-22 11:34:17','2014-05-26 04:35:59','47.6','1','22.3','32.4','23.4'),(100070101,'2014-05-22 11:44:30','2014-05-26 04:35:59','57.0','1','20.4','19.5','31.3'),(100240101,'2014-05-22 11:55:06','2014-05-26 04:39:48','59.9','1','23.1','21.1','32.9'),(100020101,'2014-05-22 12:02:23','2014-05-26 04:39:48','49.5','1','17.3','11.6','29.4'),(100260102,'2014-05-22 12:10:00','2014-05-26 04:39:48','53.0','1','22.3','31.6','25.6'),(100260101,'2014-05-22 12:23:53','2014-05-26 04:39:52','57.6','1','23.4','23.1','30.7'),(100010102,'2014-05-22 12:29:14','2014-05-26 04:39:52','58.0','1','26.5','38.0','26.3'),(100070102,'2014-05-22 12:35:15','2014-05-26 04:39:52','38.7','1','16.3','22.9','20.5');
/*!40000 ALTER TABLE `wrkstn3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wrkstn4`
--

DROP TABLE IF EXISTS `wrkstn4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wrkstn4` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `contraIndicationStatus` varchar(100) DEFAULT NULL,
  `spContraind` varchar(100) DEFAULT NULL,
  `spMethod` varchar(100) DEFAULT NULL,
  `fvc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wrkstn4`
--

LOCK TABLES `wrkstn4` WRITE;
/*!40000 ALTER TABLE `wrkstn4` DISABLE KEYS */;
INSERT INTO `wrkstn4` VALUES (100230101,'2014-05-22 10:42:58','2014-05-26 04:34:47','No','1.Pregnancy (If female) ','Manual','3.26'),(100010101,'2014-05-22 12:20:12','2014-05-26 04:34:48','No','1.Pregnancy (If female) ','Manual','3.05'),(100030103,'2014-05-22 09:44:57','2014-05-26 04:34:52','No',NULL,'Manual','3.85'),(100150101,'2014-05-22 09:52:42','2014-05-26 04:34:52','No',NULL,'Manual','4.61'),(100020102,'2014-05-22 10:03:45','2014-05-26 04:34:52','No',NULL,'Manual','2.97'),(100100101,'2014-05-22 10:10:44','2014-05-26 04:34:52','No',NULL,'Manual','1.02'),(100130102,'2014-05-22 10:18:25','2014-05-26 04:34:52','No',NULL,'Manual','3.73'),(100120101,'2014-05-22 10:23:10','2014-05-26 04:34:52','No',NULL,'Manual','2.60'),(100090102,'2014-05-22 10:29:37','2014-05-26 04:35:05','No',NULL,'Manual','3.19'),(100090103,'2014-05-22 10:35:32','2014-05-26 04:35:05','No',NULL,'Manual','2.02'),(100150102,'2014-05-22 10:47:52','2014-05-26 04:35:05','No',NULL,'Manual','1.97'),(100140101,'2014-05-22 10:51:54','2014-05-26 04:35:05','Yes','2.Active Tubeculosis ',NULL,NULL),(100120102,'2014-05-22 11:01:30','2014-05-26 04:35:06','No',NULL,'Not performed - other reason',NULL),(100050102,'2014-05-22 11:03:16','2014-05-26 04:35:06','No',NULL,'Manual','1.74'),(100100102,'2014-05-22 11:10:21','2014-05-26 04:35:06','No',NULL,'Manual','1.10'),(100060102,'2014-05-22 11:15:45','2014-05-26 04:35:06','No',NULL,'Manual','1.29'),(100240102,'2014-05-22 11:35:24','2014-05-26 04:35:59','No',NULL,'Manual','1.72'),(100210102,'2014-05-22 11:36:03','2014-05-26 04:35:59','No',NULL,'Manual','1.43'),(100160202,'2014-05-22 11:43:05','2014-05-26 04:35:59','No',NULL,'Manual','1.85'),(100070101,'2014-05-22 11:48:04','2014-05-26 04:35:59','No',NULL,'Manual','3.06'),(100240101,'2014-05-22 11:59:27','2014-05-26 04:39:48','No',NULL,'Manual','2.82'),(100020101,'2014-05-22 12:06:10','2014-05-26 04:39:48','No',NULL,'Manual','4.57'),(100260102,'2014-05-22 12:13:01','2014-05-26 04:39:48','No',NULL,'Manual','1.81'),(100260101,'2014-05-22 12:26:48','2014-05-26 04:39:52','No',NULL,'Manual','1.78'),(100010102,'2014-05-22 12:32:48','2014-05-26 04:39:52','No',NULL,'Manual','1.7'),(100070102,'2014-05-22 12:40:01','2014-05-26 04:39:52','No',NULL,'Not performed - other reason',NULL);
/*!40000 ALTER TABLE `wrkstn4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wrkstn5`
--

DROP TABLE IF EXISTS `wrkstn5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wrkstn5` (
  `memberId` bigint(10) NOT NULL,
  `starttime` varchar(100) DEFAULT NULL,
  `endtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bloodSampleAttempt` varchar(100) DEFAULT NULL,
  `reasonNobld` varchar(100) DEFAULT NULL,
  `fastTime` varchar(100) DEFAULT NULL,
  `barcodeBloodTube` varchar(100) DEFAULT NULL,
  `volumeBlood` varchar(100) DEFAULT NULL,
  `nailSampleAttempt` varchar(100) DEFAULT NULL,
  `reasonNoNail` varchar(100) DEFAULT NULL,
  `barcodeCryovial` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wrkstn5`
--

LOCK TABLES `wrkstn5` WRITE;
/*!40000 ALTER TABLE `wrkstn5` DISABLE KEYS */;
INSERT INTO `wrkstn5` VALUES (100230101,'2014-05-22 10:35:25','2014-05-26 04:34:47','Yes','Declined','1','00004000050','10','Yes','Declined','00005000009'),(100010101,'2014-05-22 12:12:30','2014-05-26 04:34:48','Yes','Declined','1','00004000019','10','Yes','Declined','00005000023'),(100030103,'2014-05-22 09:39:50','2014-05-26 04:34:52','Yes',NULL,'1','00004000031','10','Yes',NULL,'00005000001'),(100150101,'2014-05-22 09:56:34','2014-05-26 04:34:52','Yes',NULL,'1','00004000052','10','Yes',NULL,'00005000002'),(100020102,'2014-05-22 09:57:58','2014-05-26 04:34:52','Yes',NULL,'1','00004000041','10','Yes',NULL,'00005000003'),(100100101,'2014-05-22 10:06:12','2014-05-26 04:34:52','Yes',NULL,'1','00004000051','10','Yes',NULL,'00005000004'),(100130102,'2014-05-22 10:10:29','2014-05-26 04:34:52','Yes',NULL,'1','00004000021','10','Yes',NULL,'00005000005'),(100120101,'2014-05-22 10:20:31','2014-05-26 04:35:05','Yes',NULL,'1','00004000059','10','Yes',NULL,'00005000006'),(100090102,'2014-05-22 10:23:02','2014-05-26 04:35:05','Yes',NULL,'1','00004000057','10','Yes',NULL,'00005000007'),(100090103,'2014-05-22 10:30:46','2014-05-26 04:35:05','Yes',NULL,'1','00004000060','10','Yes',NULL,'00005000008'),(100150102,'2014-05-22 10:39:18','2014-05-26 04:35:06','Yes',NULL,'2','00004000040','10','Yes',NULL,'00005000010'),(100140101,'2014-05-22 10:42:57','2014-05-26 04:35:06','Yes',NULL,'1','00004000049','8','Yes',NULL,'00005000011'),(100120102,'2014-05-22 10:50:01','2014-05-26 04:35:06','Yes',NULL,'2','00004000058','10','Yes',NULL,'00005000012'),(100050102,'2014-05-22 10:58:03','2014-05-26 04:35:06','Yes',NULL,'2','00004000048','10','Yes',NULL,'00005000013'),(100100102,'2014-05-22 11:03:02','2014-05-26 04:35:06','Yes',NULL,'2','00004000039','10','Yes',NULL,'00005000014'),(100060102,'2014-05-22 11:08:32','2014-05-26 04:35:59','Yes',NULL,'1','00004000038','10','Yes',NULL,'00005000015'),(100240102,'2014-05-22 11:25:26','2014-05-26 04:35:59','Yes',NULL,'2','00004000056','10','Yes',NULL,'00005000016'),(100210102,'2014-05-22 11:30:59','2014-05-26 04:35:59','Yes',NULL,'1','00004000047','10','Yes',NULL,'00005000017'),(100160202,'2014-05-22 11:35:59','2014-05-26 04:35:59','Yes',NULL,'1','00004000030','10','Yes',NULL,'00005000018'),(100070101,'2014-05-22 11:43:14','2014-05-26 04:39:48','Yes',NULL,'2','00004000029','10','Yes',NULL,'00005000019'),(100240101,'2014-05-22 11:53:19','2014-05-26 04:39:48','Yes',NULL,'3','00004000037','10','Yes',NULL,'00005000020'),(100020101,'2014-05-22 12:00:17','2014-05-26 04:39:48','Yes',NULL,'0','00004000020','10','Yes',NULL,'00005000021'),(100260102,'2014-05-22 12:05:24','2014-05-26 04:39:48','Yes',NULL,'2','00004000055','10','Yes',NULL,'00005000022'),(100260101,'2014-05-22 12:18:57','2014-05-26 04:39:52','Yes',NULL,'4','00004000028','10','Yes',NULL,'00005000024'),(100010102,'2014-05-22 12:25:03','2014-05-26 04:39:52','Yes',NULL,'1','00004000036','10','Yes',NULL,'00005000025'),(100070102,'2014-05-22 12:31:55','2014-05-26 04:39:52','Yes',NULL,'1','00004000046','10','Yes',NULL,'00005000026');
/*!40000 ALTER TABLE `wrkstn5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wrkstn6`
--

DROP TABLE IF EXISTS `wrkstn6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wrkstn6` (
  `memberId` bigint(10) NOT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wrkstn6`
--

LOCK TABLES `wrkstn6` WRITE;
/*!40000 ALTER TABLE `wrkstn6` DISABLE KEYS */;
/*!40000 ALTER TABLE `wrkstn6` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-30  7:09:33
